
chrome.browserAction.onClicked.addListener(function(activeTab) { 
   chrome.tabs.create({'url': "/options.html" } )
});

chrome.extension.onMessage.addListener(function(t, e, a) 
{
    if (config.actions.CONTENT_CLEAR_ORDER_DATA == t.action){
        chrome.storage.sync.set({
        
            orderId: !1,
            orderItems: !1,
            orderNumber: !1,
            shopName: !1,
            currentProduct: 0,
            orderData: !1,
            defaultShipping: e.defaultShipping,
            note: !1,
            cartLoaded: !1,
            formFilled: 0,
            countrySet: 0,
            createdAt: !1,
  
        }, function() { 
            
        });    
    }
    if (config.actions.CONTENT_ORDER_FULFILLMENT_QUEUE == t.action) {
        
        var n = t.data;
        
        chrome.storage.sync.get({
            orderData: !1,
            currentProduct: 0
        }, function(o) {
            
          //  var ext_options;
            
           /* config.get_ext_options(function(data){
                ext_options = data;*/
                
                if (o.currentProduct < 1) {
                
                    chrome.tabs.create({"url":config.urls.aliexpressLink,"selected":true}, function(tab){
                        initDataStorage(n, function() {    
                            chrome.storage.sync.set({
                                maTab: e.tab,
                                cartEmpty: !1,
                            }, function() {
                                orderFulfillment(tab)
                            });     
                        });
                    }); 
                
                     
                }
                else orderFulfillment(e.tab);
               
           // }) 
            
             
        });        
    }
    
    if (config.actions.CONTENT_ORDER_TRACKING_CODE_REQUEST == t.action) {
        var n = t.data;
        
        var GetOrderDetailsPage = function(id){
            return (0, get_xhr_promise)({
                url: config.urls.orderInfo.replace("{1}", id).replace("{2}", 1 + Math.floor(Math.random() * 16) ),
                method: "GET",
                params: null,
                isForm: !0,
                isAjax: !0
            })    
        }
        
        var checkNextEl = function(id){
            return new Promise(function(resolve, reject){
                GetOrderDetailsPage(id).then(function(d){
                    resolve({data: d, order_id: id});    
                }).catch(function(s){
                    reject({order_id: id})    
                });               
     
            });    
        }
        
        var parseTrackingCodes = function(html){
            var track_codes = [];
            $(html).find(".shipping-bd > .no").each(function(){
               track_codes.push( $(this).html() );
            }); 
            
            return  track_codes;
        }
        
        var checkExistOrderNumber = function(html, order_id){
            if (  $(html).find(':contains("' + order_id + '")').length > 0) return true
            return false;    
        }
        
        var checkLoginPage = function(html){           
            if ( $(html).find("#signInField").length > 0 ) return true
            return  false;
        }
        
        var checkNoAuthPage = function(html){
            if ( $(html).find(".ui-unusual-no-authorization").length > 0 ) return true
            return  false;
             
        }
        
       // for (var o = 0; o < n.length; o++) {
    
             checkNextEl(n).then(function(d){
                 
                 var response = d.data, codes = [], s_code = 200;
                 
                 if ( checkLoginPage(response.responseText)) s_code = 401;
                else {
                     if ( !checkNoAuthPage(response.responseText) ) {
                         
                         if ( checkExistOrderNumber(response.responseText, n) ) codes = parseTrackingCodes(response.responseText);
                         else s_code = 403;
                     }
                     else s_code = 404;
                }
                 
                 chrome.tabs.sendMessage(e.tab.id, {
                    source: "ma",
                    type: config.actions.CONTENT_ORDER_TRACKING_CODE_RESPONSE,
                    data: {index: d.index, el: d.el, tracking_codes: codes, status_code: s_code}
                });
                 
         
             }).catch(function(c) {
                 
                 var response = c.message, s_code = 500;
        
                 chrome.tabs.sendMessage(e.tab.id, {
                    source: "ma",
                    type: config.actions.CONTENT_ORDER_TRACKING_CODE_RESPONSE,
                    data: {index: e.index, el: e.el, tracking_codes: [], status_code: s_code}
                });
             });
        //}
    }
    
    if (config.actions.CONTENT_ORDER_FULFILLMENT_TO_CART == t.action) {
         chrome.storage.sync.get({
            cartEmpty: !1,
        }, function(o) {
           
            o.cartEmpty !== !0 ? chrome.tabs.update(e.tab.id, {
                url: "http://shoppingcart.aliexpress.com/shopcart/shopcartDetail.htm?chrmact=clearCart"
            }) : 
            chrome.storage.sync.set({
                currentProduct: 0
            }, function() {
                chrome.tabs.update(e.tab.id, {
                    url: "http://shoppingcart.aliexpress.com/shopcart/shopcartDetail.htm?chrmact=submitCart"
                })
            });  
        });
        
    
    }
    
    if (config.actions.CONTENT_ORDER_FULFILLMENT_RESPONSE == t.action){
        
        chrome.storage.sync.get({ maTab: !1, orderId: !1}, function(o) {
            
                var ext_options;
        
                var getUpdateOrderInAppPromise = function(e){
                    return (0, get_xhr_promise)({
                        url: ext_options.root_url  + config.api.orderSync,
                        method: "POST",
                        params: e,
                        isForm: !0,
                        isAjax: !0
                    })    
                }
                
                var UpdateOrderInApp = function(i, ext_i, t) {
                    MA_Auth.ensureAuthCookie(function(ma_cookie){
                        if (ma_cookie){
                            var n = {id:i, external_id: ext_i, cookie: ma_cookie};
                            getUpdateOrderInAppPromise(n).then(function(d){
                                var p = {id: n.id, external_id: n.external_id, status: 'OK'};
                                t(p);
                            }).catch(function(e) {
                                
                                 var v_status_text = e.data ? e.data.error : e.statusText,  p = {status: 'error', id: n.id, external_id: n.external_id, status_text : v_status_text};
                                 
                                 console.log("Woocommerce Order has not been updated"), t(p);
                            })
                        } else {
                                var p = {id : i, external_id: n.external_id, status: 'error', status_text : 'Can`t generate Auth Cookie'};
                                console.log("Can't generate Auth Cookie"), t(p);
                        }
                    })
                }
                
                config.get_ext_options(function(data){
                    ext_options = data;
                    UpdateOrderInApp(o.orderId, t.id, a);    
                })  
                
               
          
            /*
            chrome.tabs.sendMessage(o.maTab.id, {
                source: "ma",
                type: config.actions.CONTENT_ORDER_FULFILLMENT_RESPONSE,
                data: {id: t.id}
            })*/
        });    
         return true;       
    }
  
    if (config.actions.CONTENT_SET_ALIEXPRESS_COOKIE == t.action){
        
  
        for (var i = 0; i < t.cookie_array.length;  i += 1){
            var cookie = t.cookie_array[i]; 
            chrome.cookies.set({
                "name": cookie.name,
                "url": 'https://www.aliexpress.com',
                "domain": cookie.params.domain,
                "path":cookie.params.path,
                "value": cookie.value
            }, function (cookie) {
                console.log(JSON.stringify(cookie));
                console.log(chrome.extension.lastError);
                console.log(chrome.runtime.lastError);
                
                var p = {'reqId':t.reqId};
                a(p);
            });
        }
        return true;    
    }
    if (config.actions.CONTENT_GET_PRODUCT_HTML == t.action) {
       
        chrome.browserAction.setBadgeText({text: "GET"});
               
        var getLoadProductHtmlPromise = function(e){
              return (0, get_xhr_promise)({
                url: e.url,
                method: "GET"
            })
             
         }
         
        var getProductHtml = function(e, i, t) {
            /*MA_Auth.ensureAuthCookie(function(ma_cookie){
                if (ma_cookie){*/
                    var r = this,   
                        n = { url: e, reqId: i/*, cookie: ma_cookie*/ };
                    getLoadProductHtmlPromise(n).then(function(d){
                        var p = {url: n.url, reqId : n.reqId, html: d.responseText};
                        chrome.browserAction.setBadgeText({text: ""}); 
                        t(p);  
                        
                    }).catch(function(e) {
                        chrome.browserAction.setBadgeText({text: ""}),
                        console.log("Product html loaded failed"), 
                        t(e)
                    })
              /*  }
            })*/
        }
      /*   
         config.get_ext_options(function(data){
            ext_options = data;*/
            getProductHtml(t.url, t.reqId, a);
        /* });*/ 
         
         return true;   
        
    }
                     
    if ( config.actions.GET_PRODUCTS_SHIPPING_INFO == t.action ){
           n = t.options,
           o = t.productIds;
           this.shippingInfo.getByIds(n, o, function(v) {
                chrome.tabs.sendMessage(e.tab.id, v)
           })    
    }               
    if ( config.actions.CONTENT_DELETE_PRODUCT_FROM_APP == t.action ){
        
        var ext_options;
        
        var getDeleteProductFromAppPromise = function(e){
            return (0, get_xhr_promise)({
                url: ext_options.root_url  + config.api.productDelete,
                method: "POST",
                params: e,
                isForm: !0,
                isAjax: !0
            })    
        }
        
        var DeleteProductFromApp = function(i, t) {
            MA_Auth.ensureAuthCookie(function(ma_cookie){
                if (ma_cookie){
                    var n = {id:i, cookie: ma_cookie};
                    getDeleteProductFromAppPromise(n).then(function(d){
                        var p = {id: n.id, status: 'OK'};
                        t(p);
                    }).catch(function(e) {
                        401 !== e.status && console.log("Product deleted" + n.id), t(e)
                    })
                } else {
                        var p = {id : i, status: 'error', status_text : 'Can`t generate Auth Cookie'};
                        console.log("Can't generate Auth Cookie"), t(p);
                }
            })
        }
        
        config.get_ext_options(function(data){
            ext_options = data;
            DeleteProductFromApp(t.id, a);     
        })    
          
        return true;   
    }
    
    
    if (  config.actions.CONTENT_TEST_CONNECTION == t.action  ){
        
        var getSyncSettingsPromise = function(e){
            
            return (0, get_xhr_promise)({
                url: ext_options.root_url + config.api.getSettings,
                method: "POST",
                params: e,
                isForm: !0,
                isAjax: !0
            })    
        }
        
        var syncSettings = function(ma_cookie){
           var n = {cookie: ma_cookie};
            getSyncSettingsPromise(n).then(function(d){
                typeof d.data !== "undefined" && 
                typeof d.data.settings !== "undefined", console.log(d.data.settings), 
                
                chrome.storage.sync.set({
                    shippingOption: d.data.settings.ali_fulfillment_prefship,
                    shippingCountry: d.data.settings.ali_aliship_shipto,
                    shippingCurrency: d.data.settings.ali_local_currency
                    /*ali_import_language*/
                }, function() {}); 
                                    
            }).catch(function(e) {
                console.log("API: syncSettings error");
            })    
        }
                
        MA_Auth.ensureAuthCookie(function(ma_cookie){
              if (ma_cookie){
                    var p = {status: 'ok', cookie: ma_cookie};
                    console.log("The connection test was Successful");
                        
                    config.get_ext_options(function(data){
                       ext_options = data;
                       syncSettings(ma_cookie);     
                    });
                
                     
                            
                        a(p);    
                   
              } else {
                  MA_Auth.getLastAuthError(function(e){
                         var p = {status: 'error', error: e};
                        console.log("The connection test was Failed"), a(p);
                  });
              }    
        });
                            
        return true;      
    }
   /* 
    if ( config.actions.CONTENT_GENERATE_AUTH_COOKIE == t.action ){
        
          var ext_options;
              
          var getAuthCookiePromise = function(e){
            return (0, get_xhr_promise)({
                url: ext_options.root_url + config.api.generateAuthCookie,
                method: "POST",
                params: e,
                isForm: !0,
                isAjax: !0
            })
          }
     
          var getAuthCookie = function(t) {
            var r = this,
                n = {username: ext_options.username, 
                     password: ext_options.password};
            getAuthCookiePromise(n).then(function(d){
                t(d.data)
            }).catch(function(e) {
                //401 !== e.status && r.logAjaxError("Product push", e), t(e)
                console.log("Generate Auth Cookie"), console.log(e), t(e)
            })
          }
          
     
          config.get_ext_options(function(v){
            ext_options = v;
            getAuthCookie(a);
          });
                            
        return true;   
    } */
    /*
    if (  config.actions.CONTENT_VALIDATE_AUTH_COOKIE == t.action ){
         var ext_options;
              
          var getValidateAuthCookiePromise = function(e){
            return (0, get_xhr_promise)({
                url: ext_options.root_url + config.api.validateAuthCookie,
                method: "POST",
                params: e,
                isForm: !0,
                isAjax: !0
            })
          }
     
          var validateAuthCookie = function(c, t) {
            var r = this,
                n = {cookie: c};
            getValidateAuthCookiePromise(n).then(function(d){
                var p = {cookie: n.cookie, status: d.statusText, valid: d.data.valid};
                t(p)
            }).catch(function(e) {
                //401 !== e.status && r.logAjaxError("Product push", e), t(e)
                console.log("Generate Auth Cookie"), console.log(e), t(e)
            })
          }
          
     
          config.get_ext_options(function(v){
            ext_options = v;
            validateAuthCookie(t.cookie, a);
          }); 
          
          return true;     
    } */
    if ( config.actions.SYNC_PRODUCT_LIST == t.action ){
    
                var ext_options;
        
                var getSyncProductListPromise = function(e){
                
                    return (0, get_xhr_promise)({
                        url: ext_options.root_url + config.api.importList,
                        method: "POST",
                        params: e,
                        isForm: !0,
                        isAjax: !0
                    })    
                }
                
                var syncProductList = function(t) {
                    
                    MA_Auth.ensureAuthCookie(function(ma_cookie){
                        if (ma_cookie){
                            var n = {cookie: ma_cookie};
                            getSyncProductListPromise(n).then(function(d){
                                var p = {products: d.data.products, status: 'OK', success:true};
                                t(p);
                            }).catch(function(e) {
                                console.log("API: syncProductList error"), e.success = false, console.log(e), t(e)
                            })
                        } else {
                            var p = {status: 'error', status_text : 'Can`t generate Auth Cookie'};
                            console.log("Can't generate Auth Cookie"), t(p);
                        }
                    })
                }
                
                
                config.get_ext_options(function(data){
                   ext_options = data;
                   syncProductList(a);     
                })    
        
        return true;   
    }
    if ( config.actions.CONTENT_PUSH_PRODUCT_TO_APP == t.action ){
        
        var ext_options;
        
        var getPushProductPromise = function(e){
              return (0, get_xhr_promise)({
                url: ext_options.root_url + config.api.productImport,
                method: "POST",
                params: e,
                isForm: !0,
                isAjax: !0
            })
             
        }
        
        var pushProduct = function(e, i, th, pmn, pmx, ttl, cur, t) {
            MA_Auth.ensureAuthCookie(function(ma_cookie){
                if (ma_cookie){
                    var r = this,
                        n = {url: e, id:i,  thumb: th,
                                price_min: pmn,
                                price_max: pmx,
                                title: ttl,
                                currency: cur, cookie: ma_cookie};
                        
                    getPushProductPromise(n).then(function(d){
                        var p = {url: n.url, id : n.id, status: 'OK'};
                        console.log("Product " + n.id + " pushed sucessfully");
                        t(p);
                    }).catch(function(e) {
                        if ( e.resultType === "timeout" ){
                            console.log("Product " + n.id + " pushed timeout");
                            setTimeout(function(){
                                pushProduct(n.url, n.id, n.thumb, n.price_min, n.price_max, n.title, n.currency, t);    
                            }, 3000);    
                        } else {
            
                            var p = {url: n.url, id : n.id, th : n.thumb, pmn : n.price_min, pmx : n.price_max, ttl : n.title, cur : n.currency, status: e.status,  status_text: e.data && e.data.error ? e.data.error :e.statusText  };
                            console.log("Product " + n.id + " pushed failed"), t(p);
                        }
                        
                    })
                } else {
                         MA_Auth.getLastAuthError(function(auth_err_txt){
                                 var p = {url: e, id:i, status: !1, status_text: auth_err_txt};
                                console.log(auth_err_txt), t(p);    
                         });     
                                     
                }
            })
        }
        
        config.get_ext_options(function(data){
            ext_options = data;
            pushProduct(t.url, t.id, t.thumb, t.price_min, 
                        t.price_max, t.title, t.currency, a);     
        }) 
        
        
        //-------------------------------   
        
        return true;    
     }
  
    if ( config.actions.GET_AND_PUSH_PRODUCT_HTML_TO_APP == t.action ){
       
        chrome.browserAction.setBadgeText({text: "GET"});
          
        var ext_options;
        
        var getPushProductHtmlPromise = function(e){
              return (0, get_xhr_promise)({
               // url: ext_options.root_url + config.api.productImportUpdate,
               url: ext_options.root_url + config.api.productImport,
                method: "POST",
                params: e,
                isForm: !0,
                isAjax: !0 
            })
             
         }
         
        var pushProductHtml = function(i, u, h, s, t) {
            MA_Auth.ensureAuthCookie(function(ma_cookie){
                if (ma_cookie){
                    var r = this,
                        n = { id:i, html:encodeURIComponent(h), shipdata:s, cookie: ma_cookie, url: u };
                    getPushProductHtmlPromise(n).then(function(d){
                        t({id : n.id, url: n.url, status: 'OK'})
                    }).catch(function(e) {
                        
                        var p = {url: n.url, id : n.id, status: e.status};
                        console.log("Product html pushed failed"), t(p);
            
                    })
                }
            })
        }
         
         //-------------------
        var getProductShippingInfoPromise = function(i){
            
        } 
          //-------------------
         
        var getLoadProductHtmlPromise = function(e){
              return (0, get_xhr_promise)({
                url: e.url,
                method: "GET"
            })
             
         }
         
        var getProductHtml = function(e, i, th, pmn, pmx, ttl, cur, t) {
            MA_Auth.ensureAuthCookie(function(ma_cookie){
                
                  var r = this,
                        n = { url: e, id: i, thumb: th,
                                price_min: pmn,
                                price_max: pmx,
                                title: ttl,
                                currency: cur, cookie: ma_cookie };
                                
                if (ma_cookie){
                  
                    getLoadProductHtmlPromise(n).then(function(d){
                          chrome.browserAction.setBadgeText({text: ""});
                          
                          var opts = ext_options /*config.defaultShippingSettings*/, 
                          o = n.id;
           
                          shippingInfo.getByIds(opts, [o], function(e) {
                               var p = {url: n.url, id : n.id, html: d.responseText, shipdata : e.freight};
           
                               pushProductHtml(p.id, p.url, p.html, p.shipdata, t );
                          });
               
                       
                     
                    }).catch(function(e) {
                        chrome.browserAction.setBadgeText({text: ""});
                        var p = {url: n.url, id : n.id, status: e.status};
                        console.log("Product html load failed"), t(p);
                    })
                } else {
                    chrome.browserAction.setBadgeText({text: ""});
                    var p = {url: n.url, id : n.id, status: !1, status_text: 'Authentication was failed'};
                    console.log("Authentication was failed"), t(p);    
                }
            })
        }
         
         config.get_ext_options(function(data){
            ext_options = data;
            getProductHtml(t.url, t.id, t.thumb, t.price_min, 
                        t.price_max, t.title, t.currency, a);
         }) 
         
         ///----------

         
         return true;   
     }
     
    if ( config.actions.CONTENT_OPEN_SETTING_TAB == t.action ){
        chrome.tabs.create({'url': "/options.html" } )    
    }                       
});

