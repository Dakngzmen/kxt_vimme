var get_xhr_promise = function(e) {
    
    var u = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    };
    
    function r(e, t) {
        var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
            o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
            i = Array.isArray(t);
        for (var a in t) {
            var s = t[a];
            o && (a = n ? o : o + "[" + (i ? "" : a) + "]"), 
            !o && i ? e.push(encodeURIComponent(s.name) + "=" + encodeURIComponent(s.value)) : 
            (n ? Array.isArray(s) : "object" === ("undefined" == typeof s ? "undefined" : u(s))) ? r(e, s, n, a) : e.push(encodeURIComponent(a) + "=" + encodeURIComponent(s))
        }
    }

    function n(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            n = [];
        return r(n, e, t), n.join("&").replace("%20", "+")
    }
    
    function i(e, t, r) {
        var n = {
                url: e.url,
                requestData: e.params,
                success: !1,
                data: null,
                status: t.status,
                responseText: t.responseText,
                responseURL: t.responseURL,
                readyState: t.readyState,
                resultType: r.type,
                reason: "",
                errors: [],
                statusText: t.statusText
            },
            i = o(n);
    return i && (n.data = i, n.responseText = "", n.data.errors && (n.errors = n.data.errors), n.data.reason && (n.reason = n.data.reason)), n
    }
    
    function a(e, t, r) {
         if (t.status >= 200 && t.status < 300) {
            var n = {
                url: e.url,
                requestData: e.params,
                success: !0,
                data: null,
                status: t.status,
                responseText: t.responseText,
                responseURL: t.responseURL,
                readyState: t.readyState,
                resultType: r.type,
                statusText: t.statusText,
                reason: "",
                errors: []
            };
            return n.data = o(n), n
        }
    return i(e, t, r)
    }
        
    function o(e) {
        var t = e.responseText.replace(/(?:\r\n|\r|\n|^\(|\)$)/g, ""),
        t = t.replace('\ufeff', ''),
            r = t.match(/<body[^>]*>((.|[\n\r])*)<\/body>/im);
        if (r) return r[1] || "";
        try {
            return JSON.parse(t)
        } catch (e) {}
        return null
    }
    var c = 15e3;
    var pp = new Promise(function(t, r) {
        var o = Object.assign({
                url: "",
                method: "GET",
                headers: null,
                params: null,
                isForm: !1,
                isAjax: !1,
                timeout: c
            }, e),
            s = new XMLHttpRequest;
            
        s.open(o.method, o.url), s.timeout = o.timeout;
       
        var l = function(e) {
                r(i(o, s, e))
            },
            d = function(e) {
                var n = a(o, s, e);
                n.success ? t(n) : r(n)
            };
        
         s.addEventListener("load", d);
      
         s.addEventListener("timeout", l); 
         s.addEventListener("error", l), s.addEventListener("abort", l); 
         o.isForm && s.setRequestHeader("Content-type", "application/x-www-form-urlencoded"); 
         o.isAjax && s.setRequestHeader("X-Requested-With", "XMLHttpRequest"); 
         o.headers && Object.keys(o.headers).forEach(function(e) {
            s.setRequestHeader(e, o.headers[e])
         });
        var f = o.params;
        
        f && "object" === ("undefined" == typeof f ? "undefined" : u(f)) && (f = o.isForm ? n(f) : JSON.stringify(f));
        
        s.send(f)
    });
    
    return pp;
}
    
lruCache = function(){
       
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 500,
        r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3;
    
    this.maxItemsCount = t, this.itemExpiration = r, this.cache = new Map;
}

lruCache.prototype.set = function(e, t){
    t.dateTime = (new Date).getTime(), this.cache.set(e, t), Math.random() < .6 && this.purge();   
}

lruCache.prototype.get = function(e){
    var t = this.cache.get(e);
    if (t) {
        var r = (new Date).getTime();
        if (r - t.dateTime < this.itemExpiration) return t.dateTime = r, this.cache.delete(e), this.cache.set(e, t), t;
        this.cache.delete(e)
    }
    return null
}

lruCache.prototype.purge = function(){
     if (this.cache.size > this.maxItemsCount) {
        var e = [].concat(r(this.cache.keys())),
            t = this.maxItemsCount - this.cache.size;
        e.splice(t, this.maxItemsCount);
        for (var n = 0; n < e.length; n += 1) {
            var o = e[n];
            this.cache.delete(o)
        }
     }   
}

var shippingInfo = {
     lruCache : new lruCache(1e3,36e5),
     getByIds : function(e, t, r) {
         var n = this;

         this.ajaxFailed = !1, this.totalFailed = 0, t.forEach(function(t) {
           
            var o = config.urls.shippingInfo.replace("{1}", t).replace("{2}", e.shippingCountry.toUpperCase()).replace("{3}", "1").replace("{4}", e.shippingCurrency.toUpperCase()),
                i = n.lruCache.get(o);
     
            i ? r(i) : n.getRemotePromise(t, o).then(r)/*.catch(r)*/
         })
     },
     tryGettingFreight : function(e, t, r) {
        var n = this,
            o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
            i = r || new Promise,
            a = function(r, a) {
                if (r) i.resolve(a);
                else if (o < 5) {
                    var s = 2 * (o * o);
                    setTimeout(function() {
                        n.tryGettingFreight(e, t, i, o + 1)
                    }, s)
                } else n.totalFailed += 1, n.ajaxFailed = n.totalFailed > g || 0 === a.response.readyState || 0 === a.response.status || 400 === a.response.status || 401 === a.response.status, i.reject(a)
            };
        (0, get_xhr_promise)({
            url: t,
            method: "GET"
        }).then(function(r) {
            var o = r && r.data && r.data.freight ? r.data.freight : [],
                i = {
                    productId: e,
                    freight: o
                };
            if (Array.isArray(o) && o.length > 0) try {
                n.lruCache.set(t, i)
            } catch (e) {} else i.freight = [];
            a(!0, i)
        }).catch(function(r) {
          
            a(!1, {
                productId: e,
                url: t,
                error: 'error',
                response: r
            })
        })
     },
     getRemotePromise : function(e, t) {
        var r = jQuery.Deferred();
        return this.ajaxFailed ? r.reject({
            productId: e,
            url: t,
            error: "Throttling because of errors"
        }) : this.tryGettingFreight(e, t, r), r
     }, 
     getResponseErrorMessage : function(e) {
        var t = h(e.url),
            r = "";
        return r = e.errors.length > 0 ? e.errors.join(". ") : 0 === e.readyState || 0 === e.status ? "Could not connect to " + t : 401 === e.status ? "Please login to " + t + " and try again" : "Unhandled error while connecting to " + t
     },

}

var initDataStorage = function(e, r) {
    for (var t = [], o = 0; o < e.products.length; o++) t[o] = e.products[o];

    //e.products = t;
    chrome.storage.sync.set({
        orderId: e.id,
        orderItems: JSON.stringify(t),
        orderNumber: e.orderNumber,
        shopName: e.shopName,
        currentProduct: 0,
        orderData: JSON.stringify(e),
        defaultShipping: e.defaultShipping,
        note: e.note,
        cartLoaded: !1,
        formFilled: 0,
        countrySet: 0,
        createdAt: Date.now()
    }, function(){ r() })
}

var orderFulfillment = function(tab){
     chrome.storage.sync.get({
                orderData: !1,
                currentProduct: 0
    }, function(e) {
        console.log(e.orderData);
        var t = JSON.parse(e.orderData);
    
        console.log(t);
        var    a = e.currentProduct + 1;
        var    s = t.products[a-1].url;
         
        chrome.storage.sync.set({
            currentProduct: a
        }, function(e) { 
            chrome.tabs.update(tab.id, {
                url: s
            },  function(tab){
                
            })
        })
    });    
}