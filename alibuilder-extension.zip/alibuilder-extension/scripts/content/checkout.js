function init() { 
	chrome.storage.sync.get({
        orderId: 0,
        orderNumber: "",
		shopName: "",
		orderData: !1,
		defaultShipping: "",
		note: "",
        formFilled: 0,
		countrySet: 0,
		createdAt: 0
	}, function(e) {
         
        
		if (e.orderData !== !1){
			if (Date.now() - e.createdAt <= 720 * 1000) { //12 min
				var t = trimOrderData(e.orderData);
                
				if (validateProducts(t.products)) { 
                
					var n = 0 == jQuery(".sa-address-row").length;
					n ? 0 == e.countrySet  
							? chrome.storage.sync.set({ countrySet: 1}, 
							  function() {
                                
								createAddress(t)
							  }) 
							: chrome.storage.sync.set({ orderData: !1 }, 
							  function() {
								createAddress(t)
							  }) 
					  : 0 == e.formFilled 
										? chrome.storage.sync.set({ formFilled: 1}, 
										  function() {
                                       
										   clickButton("sa-edit"), MAStatusBar.add("Editing customer shipping details..."),
                                            editAddress(t)
										  }) 
										: chrome.storage.sync.set({ orderData: !1 }, 
										   function() {
                                              fillNotes(e.note);
                                              setTimeout(function(){
                                                selectShipping(e.defaultShipping)
                                              }, 1500);   											       
										   })
				}
			} else chrome.runtime.sendMessage({
				    action: config.actions.CONTENT_CLEAR_ORDER_DATA
			});
        }
		else {
            //after country has been chosen and checkout has been page reload
            fillNotes(e.note); 
            setTimeout(function(){
                selectShipping(e.defaultShipping)
            }, 1500); 
        }
		
	})
}

function validateProducts(e) {
	console.log('validate products');
	if ("undefined" == typeof e || e.length < 1) return !1;
	for (var t = 0; t < e.length; t++) {
		var n = e[t],
			i = jQuery('tr[productid="' + n.productId + '"');
		if (!i.length) return !1
	}
	return !0
}

function createAddress(e) {
	MAStatusBar.add("Adding customer shipping details..."), setLocation(e.countryRegion, e.region, e.city), setTimeout(function() {
		if (fillInput('[name="contactPerson"]', e.contactName), fillInput('[name="address"]', e.address1), fillInput('[name="address2"]', e.address2), "" == e.zip) {
			var t = jQuery(".sa-no-zip-code").find("input");
			0 == t.prop("checked") && t.click()
		} else jQuery(".sa-no-zip-code").find("input").prop("checked", !1), fillInput('[name="zip"]', e.zip);
        if (typeof e.mobile_code !== "undefined") fillInput('[name="phoneCountry"]', e.mobile_code)
		fillInput('[name="mobileNo"]', e.mobile),
        /*validateShippingDetails(e) &&*/ (clickButton("sa-confirm"), finish())
	}, 739)
}

function trimOrderData(e) {
	return e = JSON.parse(e), e.city = jQuery("<div/>").html(e.city).text(), e.contactName = jQuery("<div/>").html(e.contactName).text(), e.address1 = jQuery("<div/>").html(e.address1).text(), e.address2 = jQuery("<div/>").html(e.address2).text(), e
}

function validateShippingDetails(e) {
	var t = [];
	jQuery('[name="contactPerson"]').val() != e.contactName && t.push("Contact name"), jQuery('[name="country"]').val() != e.countryRegion && t.push("Country"), jQuery('[name="address"]').val() != e.address1 && t.push("Address 1"), jQuery('[name="address2"]').val() != e.address2 && t.push("Address 1"), jQuery('[name="city"]').val() != e.city && t.push("City");
	var n = jQuery('[name="province"]'),
		i = n.parent().find("select");
	return i.is(":visible") ? i.val() != e.region && t.push("State/Province/Region") : n.val() != e.region && t.push("State/Province/Region"), jQuery('[name="mobileNo"]').val() != e.mobile && t.push("Mobile number"), 
    
    !(t.length > 0) || (jQuery("div.order-warn-tips").append('oook'/*renderAddressValidationFail(t)*/), !1)
}

function editAddress(e) {
	var t = jQuery("#address-main").find(".sa-form");
	jQuery(t).is(":visible") ? (setLocation(e.countryRegion, e.region, e.city), setTimeout(function() {
		if (fillInput('[name="contactPerson"]', e.contactName), fillInput('[name="address"]', e.address1), fillInput('[name="address2"]', e.address2), "" == e.zip) {
			var t = jQuery(".sa-no-zip-code").find("input");
			0 == t.prop("checked") && t.click()
		} else jQuery(".sa-no-zip-code").find("input").prop("checked", !1), fillInput('[name="zip"]', e.zip);
        
        
        if (typeof e.mobile_code !== "undefined") fillInput('[name="phoneCountry"]', e.mobile_code)
        fillInput('[name="mobileNo"]', e.mobile),(clickButton("sa-confirm"), finish());
        
        /*
        var mobile = e.mobile;
        if (typeof e.mobile_code !== "undefined" && e.mobile_code !== "") {
            mobile = e.mobile_code + '' + mobile;   
        }

		fillInput('[name="phoneCountry"]', 0),
        fillInput('[name="phoneArea"]', '-'),
        fillInput('[name="phoneNumber"]', '-')
        fillInput('[name="mobileNo"]', mobile), (clickButton("sa-confirm"), finish());*/
      
	}, 2e3)) : setTimeout(function() {
		editAddress(e)
	}, 500)
}

function setLocation(e, t, n) {
    if (t == "") t = e;
	var i = new Event("change");
	fillInput('[name="country"]', e), setTimeout(function() {
		document.getElementsByName("country")[0].dispatchEvent(i)
	}, 500), setTimeout(function() {
		var e = jQuery('[name="province"]').parent().find("select");
        
        if ( jQuery(e).is(":visible") ){
            
            var matchingValue = e.find('option').filter(function () { 
                return this.value.toLowerCase() == t.toLowerCase(); 
            } ).attr('value');
            
            jQuery(e).val(matchingValue);
        } else {
            fillInput('[name="province"]', t)
        }
        
        document.getElementsByName("province")[0].dispatchEvent(i);     
	
	}, 1000), setTimeout(function() {
		var e = jQuery('[name="city"]').parent().find("select");
		jQuery(e).is(":visible") ? (jQuery(e).val(n), jQuery(e).change()) : fillInput('[name="city"]', n), document.getElementsByName("city")[0].dispatchEvent(i)
	}, 2000)
}

function fillNotes(e) {
	if ("" != e){
              
        setTimeout(function() {   
            MAStatusBar.add("Filling order notes..."); 
            for (var t = document.getElementsByClassName("message-text"), i = 0; i < t.length; i++) 
                t[i].value = e;
                
                 setTimeout(function() { MAStatusBar.remove() }, 400);
        }, 700);           
    }
		
}

function selectShipping(e) {
	if ("" != e) {
        setTimeout(function() {  
            MAStatusBar.add("Selecting shipping method...");          
       
		    if ("ePacket" == e) {
			    var t = 0,
				    n = [];
			    jQuery("label.shipping-label").each(function() {
				    var e = jQuery(this).text(),
					    i = e.match(/ePacket/g);
				    if (null != i) {
					    var r = jQuery(this).find('input[type="radio"]:not(:checked)');
					    r.length > 0 && (n[t] = r, t++)
				    }
			    }), jQuery("div.shipping-displayname").each(function() {
				    var e = jQuery(this).text(),
					    i = e.match(/ePacket/g);
				    if (null != i) {
					    var r = jQuery(this).parent().parent().find('input[type="radio"]:not(:checked)');
					    r.length > 0 && (n[t] = r, t++)
				    }
			    })
		    } else var n = jQuery('input[value="' + e + '"]:not(:checked)');
		    
            setTimeout(function() {  
		        if (n.length > 0) {
			        var i = jQuery(n[0]),
				        r = i.closest("div.pnl-shipping").find("input.btn-ok");
			        i.prop("checked", !0), r.click()
		        } else MAStatusBar.remove(), chrome.storage.sync.set({
			        defaultShipping: ""
		        })
            }, 400);
        
        }, 720);
        
	}
}

function finish() {
	chrome.storage.sync.set({
		orderData: !1
	}), console.log('finish');
}

function waitForAddressList() {
	jQuery("#address-main").hasClass("loaded") ? init() : setTimeout(function() {
		waitForAddressList()
	}, 200)
}

function clickButton(e) {
    
    setTimeout(function() {
        document.getElementsByClassName(e)[0].click();
    }, 600);
    
	
}

function fillInput(e, t) {
	jQuery.contains(document.documentElement, jQuery(e)[0]) ? jQuery(e).val(t) : 
    console.log(e + " field not found")
}

function checkOrderID(){
    var val = document.URL;
    var param = "orderIds";
    if (val.indexOf(param) > -1) {
        var url = val.substr(val.indexOf(param));
        var n = parseInt(url.replace(param+"=",""));
        
        return n;
    }
    
    return -1;
}
jQuery(document).ready(function() {
    document.body.classList.add("ma"), document.body.classList.add("ma-checkout"),
	jQuery("body").append(MAMessages.statusBar()), waitForAddressList();
    
    setTimeout(function() {
        var i = checkOrderID();
        if (i > -1) MAOrder.updateOrder({ id: i}); 
    }, 600)
    
    
});