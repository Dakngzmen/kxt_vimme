(function(){
    var ext_options = {};
    var MACategoryPage = {
        listBox : !1,
        listView : !1,
        listViewBelow : !1,
        galleryView : !1,
        listItemsNode : !1,
        options : !1,
        preInit : function() {
            var e = MACategoryPage;
   
            mainPanel.render(), e.initPage();
                
      
             e.listBox = document.querySelectorAll("ul.list-box"), 
             e.listView = document.querySelector("ul#hs-list-items") ? document.querySelector("ul#hs-list-items") : (document.querySelector("ul.prime-list") ? document.querySelector("ul.prime-list") : document.querySelector("div.prime-list ul") ), 
             e.listViewBelow = document.querySelector("#hs-below-list-items ul"), 
             e.galleryView = document.querySelector("ul.son-list"), 
             
             e.listItemsNode = document.querySelector("ul#list-items") ? document.querySelector("ul#list-items") : ( document.querySelector(".items-list") ? document.querySelector(".items-list") : document.querySelector("ul.list-items") ),
             e.listView || e.galleryView || e.listItemsNode || e.listBox ? function (t) { e.initShipping(t)}(/*config.defaultShippingSettings*/ext_options) : console.log("Category items list not found")

        },
      
        initPage : function() {
            var e = MACategoryPage;
          chrome.runtime.onMessage.addListener(function (t) {
                    e.processResponseProduct(t)
                }), document.body.classList.add("ma"), document.body.classList.add("ma-category")

        },
        initShipping : function(e) {
            var eo = MACategoryPage;
            
            eo.productIds = []
                , eo.options = e
                , eo.listView ? (eo.startDomObserver(eo.listView)
                    , eo.prepareNodes(eo.listView.children)
                    , eo.listViewBelow && (eo.startDomObserver(eo.listViewBelow)
                        , eo.prepareNodes(eo.listViewBelow.children))) :
                eo.galleryView ?
                (eo.galleryView.attributes.id && eo.galleryView.attributes.removeNamedItem("id")
                    , eo.startDomObserver(eo.galleryView), eo.prepareNodes(eo.galleryView.children)
                ) :
                eo.listItemsNode && (eo.startDomObserver(eo.listItemsNode), ( $(eo.listItemsNode).find('li').length ? eo.prepareNodes($(eo.listItemsNode).find('li')) : eo.prepareNodes(eo.listItemsNode.children)));
                
                if (eo.listBox) {
                     eo.listBox.forEach(function (e) {
                        eo.startDomObserver(e);
                        eo.prepareNodes(e.children);
                    });    
                }
                 
        },
        startDomObserver : function(e) {
            var t = MACategoryPage
                , r = function (e) {

                    e.forEach(function (e) {
                        "childList" === e.type && e.addedNodes.length > 0 && ($(e.addedNodes).find('li').length ? t.prepareNodes($(e.addedNodes).find('li')) : t.prepareNodes(e.addedNodes));
                    })
                }
                , n = new MutationObserver(r);
            n.observe(e, {
                attributes: !1
                , childList: !0
                , characterData: !1
            })
        },
        prepareNodes : function(e) {

            var f = function(e){
                var eo = MACategoryPage;

                for (var t = 0; t < e.length; t += 1) {
                    var r = e[t];

                    eo.prepareNode(r);


                }

                eo.options.showShipping && chrome.runtime.sendMessage({
                    action: config.actions.GET_PRODUCTS_SHIPPING_INFO
                    , productIds: eo.productIds
                    , options: eo.options
                })
            }

            if ( $(e).find(".lazyload-placeholder").length === 0 ) {
                f(e);
            } else {

                $(e).find(".lazyload-placeholder").each(function(){

                    var observer = new MutationObserver(function (e, obs) {

                        var r_e = [];

                        e.forEach(function (e) {
                            e.addedNodes.length > 0 && $( e.addedNodes[0]).hasClass('product-img'), obs.disconnect(), r_e.push($(e.addedNodes[0]).parents('li')[0]);
                        })

                        if (r_e.length){
                            f(r_e);
                        }
                    });

                    var pn  = $(this).parents('li')[0];
                    observer.observe(pn, {
                        childList: true,
                        subtree: true

                    });
                });

                var r_e = [];

                $(e).each(function() {
                    if ($(this).find(".lazyload-placeholder").length === 0){
                        r_e.push(this);
                    }
                });

                f(r_e);

            }

        },
        prepareNode : function(e) {
            var t = MACategoryPage, mp = mainPanel,
                d = mp.getProductData(e);

            if (!d) return;

            var r = d.id;
            r && ! function () {
                var n = d.url
                    , o = e.querySelector("div.info-more");
                    
                    if ( o ) {
                        MAHtml.prependHtml(document, o, MAMessages.categoryPushButton());
                    } else {
                        jQuery(e).css('position','relative'); 
                        MAHtml.prependHtml(document, e, MAMessages.categoryPushButton());    
                    }
               
                var i = e.querySelector(".ma-btn-push-category-product");
                i && i.addEventListener("click", function (e) {
                    e.preventDefault(), MAProduct.pushProduct(n, r, d.thumb, d.price_min, d.price_max, d.title, d.currency).catch(function(){});
                }), t.productIds.includes(r) || t.productIds.push(r)
            }()
        },
        getCurrency : function(e){
           return document.querySelector("span.currency").innerText
        },                        
        processResponseProduct : function(e) {
            var t = MACategoryPage
                , r = document.querySelectorAll('[value="' + e.productId + '"].atc-product-id');
                
            if (r.length > 0){  
                r.forEach(function (r) {
                    var n = (0, t.findParentBySelector)(r, ".list-item") ? (0, t.findParentBySelector)(r, ".list-item") : (0, t.findParentBySelector)(r, ".item");
                    n && e.freight && t.renderShipping(t.options, e.freight, n)
                })
            }            
            else {
                r = jQuery('li a[href*="'+e.productId+'"]');
                if (r.length > 0) {
                    r = r[0];
                    n = jQuery(r).parents('li');
                    
                    if (n.length > 0 && e.freight){
                        n = n[0];
                        t.renderShipping2(t.options, e.freight, n);    
                    }
                }
            }
        },
        getImgCssClass : function(e) {
            var t = "large"
                , r = parseInt(e.getPropertyValue("width"), 10)
                , n = parseInt(e.getPropertyValue("padding-left"), 10);
            return 960 === r ? t = "small" : 220 === r && 8 === n && (t = "medium"), t
        },
        changeImgMaxSize : function(e, t, r) {
            var n = parseInt(t.getPropertyValue("max-height"), 10) + r
                , o = parseInt(t.getPropertyValue("max-width"), 10) + r;
            e.style["max-height"] = n + "px", e.style["max-width"] = o + "px"
        },
        renderShipping : function(e, t, r) {
            var eo = MACategoryPage;
            
            var n = config.shippingOptions.find(function (t) {
                    return t.v === e.shippingOption
                })
                , o = n ? n.v : e.shippingOption
                , i = n ? n.t : e.shippingOption
                , a = t.find(function (e) {
                    return e.company === o
                })
                , s = r.querySelector(".img img");
                
            if (s) {
                var u = window.getComputedStyle(s)
                    , c = eo.getImgCssClass(u)
                    , l = (0, eo.findParentBySelector)(s, "div.img");
                if (!a && e.showOnlyActive || eo.changeImgMaxSize(s, u, -6), l)
                    if (a) {
                        var d = a.price > 0 ? a.localPriceFormatStr : "Free"
                            , f = l.querySelector("a");
                        if (f && (f.style.border = "3px solid #283891"), (0, MAHtml.appendHtml)(document, l, eo.renderShippingOptionAvailable(a.companyDisplayName, d, c)), e.showProcessing && a.processingTime > 0) {
                            var h = r.querySelector(".picRind") ? r.querySelector(".picRind") : r.querySelector(".pic-rind");
                            h && (h.style.position = "relative", (0, MAHtml.appendHtml)(document, h, eo.renderProcessingTime(a.processingTime)))
                        }
                        
                        if (a.time) {
                               var h = r.querySelector(".picRind") ? r.querySelector(".picRind") : r.querySelector(".pic-rind");
                            h && (h.style.position = "relative", (0, MAHtml.appendHtml)(document, h,  eo.renderDeliveryTime(a.time)))
                        }
                       
                        
                    } else if (e.showOnlyActive) r.remove();
                    
                    
                else {
                    var y = l.querySelector("a");
                    y && (y.style.border = "3px solid #F1B64F"), (0, MAHtml.appendHtml)(document, l, eo.renderNoShippingOptionAvailable(i, c))
                }
            }
        },
        renderShipping2 : function(e, t, r){


            function w_e(h) {
                return new Promise(function(n, t) {
                    var i = setInterval(function() {
                        jQuery(h).find(".product-img")
                            .length && (clearInterval(i), setTimeout(function() {
                            return n(!0)
                        }, 300))
                    }, 300)
                })
            }
            
            var eo = MACategoryPage;
            
            var n = config.shippingOptions.find(function (t) {
                return t.v === e.shippingOption
            })
                , o = n ? n.v : e.shippingOption
                , i = n ? n.t : e.shippingOption
                , a = t.find(function (e) {
                    return e.company === o
                });

            w_e(r).then(function(){
                var /*u = window.getComputedStyle(s)
                , c = eo.getImgCssClass(u)*/
                    c = 'large',
                    l = jQuery(r).find('.product-img img'),
                    f = jQuery(r).find('.product-card'),
                    h = jQuery(r).find('.product-img');

                //l.find('.product-img').css('overflow-x','hidden').css('width','auto');

                f.css('padding-top','0');
                l.css('overflow','visible');
                h.css('position','relative');

                if (a) {
                    var d = a.price > 0 ? a.localPriceFormatStr : "Free";

                    if (f && (f.css('border',"3px solid #283891")), (0, MAHtml.appendHtml)(document, f[0], eo.renderShippingOptionAvailable(a.companyDisplayName, d, c)), e.showProcessing && a.processingTime > 0) {

                        MAHtml.appendHtml(document, h[0], eo.renderProcessingTime(a.processingTime));
                    }

                    if (a.time) {
                        MAHtml.appendHtml(document, h[0],  eo.renderDeliveryTime(a.time));
                    }


                } else if (e.showOnlyActive) r.remove();
                else {


                    var y = f;
                    y && (y.css('border',"3px solid #F1B64F"), (0, MAHtml.appendHtml)(document, h[0], eo.renderNoShippingOptionAvailable(i, c)));
                }
            });

        },
        findParentBySelector : function(e, t) {
                
                
                for (var r = null, n = e.parentElement, o = function() {
                        return n.matches(t) && (r = n), r
                    }; n && !o();) n = n.parentElement;
                return r
        },
        showFailMessage : function(e) {
            var eo = MACategoryPage;
            
            if (!eo.errorMessage) {
                eo.errorMessage = !0;
                var t = eo.messages.shippingDetailsFailedMessage(e.url, e.error)
                    , r = eo.document.querySelector("#ma-error-container");
                r && (r.innerHTML = t), eo.logScriptError("Shipping info errors", e)
            }
        },
       
        renderShippingOptionAvailable : function(e, t, r) {
            return '<div class="ma-shipping has-options ' + r + '"><span>' + e + "</span><span>" + t + "</span></div>"
        },
        renderNoShippingOptionAvailable : function(e, t) {
            return '<div class="ma-shipping no-options ' + t + '"><span>No ' + e + "</span></div>"
        },
        renderProcessingTime : function(e) {
            var t = "Processing time: " + e + " Days";
            return '<div class="ma-processing-time" title="' + t + '">\n                <span class="first">Processing Time</span>\n                <span class="last">' + e + " Days</span>\n            </div>"
        },
        renderDeliveryTime : function(e) {
            var t = "Delivery time: " + e + " Days";
            return '<div class="ma-delivery-time" title="' + t + '">\n                <span class="first">Delivery Time</span>\n                <span class="last">' + e + " Days</span>\n            </div>"
        }
    };
   
   config.get_ext_options(function(data){
       ext_options = data;
       return new Promise(function(j,h) {


           var k = 0, i = setInterval(function() {
               if ($("span.currency").length ){
                   clearInterval(i);
                   j();
               } else {
                   k++;

                   if (k > 30){
                       h();
                   }
               }
           },500);
       }).then(function(){
           setTimeout(MACategoryPage.preInit, 300);
       }).catch(function(){
           alert('Some error occured. It looks like AlIExpress change the page template, please contact support.');
       });


      // MACategoryPage.preInit();   
   });



}());