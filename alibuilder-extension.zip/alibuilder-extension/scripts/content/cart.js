function clearCartAndContinue() {
    MAStatusBar.add("Clearing cart..."),
	chrome.storage.sync.set({
		continueAfterRefresh: !0
	}, function() {
        var o = MAPromises;
        
        o.waitEl('#nav-cart-num')
            .then(function(e){
                if (parseInt($(e).text())){
                    if ( $('.remove-all-product').length){  
               
                        o.clickBtn(".remove-all-product")
                        .then(function(e) {
                            return o.clickBtn('input[data-role="submit"]');
                        })
                        .then(null,function(b){
                            console.log('somethig go wrong')
                        });
                                     
                    } else if ( $('button[ae_button_type="remove"]').length){
                        
                         var do_remove = function(arr, ind, func){
                
                            if (ind == arr.length){
                                return func();  
                            }
                            
                            var el = arr[ind];
                            
                            o.clickBtn(el)
                                .then(function(){
                                    return o.clickBtn('.next-dialog-footer>button');
                                })
                                .then(function(){
                                   do_remove(arr, ind+1,function(){
                                        orderProducts();
                                    });
                                });
                         }
                         
                         var remove_buttons = $('button[ae_button_type="remove"]');
                         
                         do_remove(remove_buttons, 0);   
                    }    
                }
                else  orderProducts();     
            })
             .then(null,function(b){
                console.log('somethig go wrong 2')
             });
        
	});
}
/* function clearCartAndContinue() {
    MAStatusBar.add("Clearing cart..."),
	chrome.storage.sync.set({
		continueAfterRefresh: !0
	}, function() {
        jQuery('.remove-all-product').length > 0 ? (
		document.getElementsByClassName("remove-all-product")[0].click(),  
        waitForRemoveAllProduct() ) : orderProducts()
	});
} */

function waitForRemoveAllProduct() {
    
    jQuery('.ui-window').length > 0 ? function(){ 
        jQuery('.ui-window input[data-role="submit"]').click()}() : 
        setTimeout(function() {
        waitForRemoveAllProduct()
    }, 200)
}

function orderProducts() {
	chrome.storage.sync.set({
		continueAfterRefresh: !1,
        cartEmpty: !0
	}, function() {
		chrome.storage.sync.get({
			orderData: !1,
			currentProduct: 0
		}, function(e) {
			if (e.orderData !== !1) {
				var r = JSON.parse(e.orderData),
				t = r.products[e.currentProduct-1];  
                window.location = t.url;
			}
		})
	})
}

function submitCart() {
	MAStatusBar.add("Submitting cart...");
    
    function u(e, p) {
          
        return new Promise(function(n, t) {
            var i = setInterval(function() {
               if ($(e).length || $(p).length){
                    
                   clearInterval(i);
                    
                    setTimeout(function() {
                        return n(!0)
                    }, 300);
               }  
              
            }, 300)
        })
                
    }
    
    u('#checkout-button', ".buy-now").then(function(){
        
        if ($('#checkout-button').length > 0){
             chrome.storage.sync.get({
                orderId: 0,
                orderNumber: "",
                shopName: "",
                orderData: !1,
                defaultShipping: "",
                note: "",
                formFilled: 0,
                countrySet: 0,
                createdAt: 0
            }, function(e) {
                    
                new_cart_handler(e);
                });
        } else {
            $(".buy-now").eq(0).click();    
        }   
    })	
	/*MAStatusBar.add("selecting cart products ..."), document.getElementsByClassName("next-checkbox-label")[0].click();
	MAStatusBar.add("cart products ..."), document.getElementsByClassName("click-mask")[0].click();
	MAStatusBar.add("Submitting cart..."), document.getElementById("checkout-button").click();
	 //MAStatusBar.add("Submitting cart..."), document.getElementsByClassName("buy-now")[0].click(); */
}

function new_cart_handler(d){
    
        function l(e) {
            return new Promise(function(n, t) {
                var i = setInterval(function() {
                    if ($(e).length) return clearInterval(i), n(!0)
                }, 300)
            })
        }
        
        function u(e) {
            return l(e)
                .then(function() {
                    return new Promise(function(n, t) {
                        var i = setInterval(function() {
                            $(e).length || (clearInterval(i), setTimeout(function() {
                                return n(!0)
                            }, 300))
                        }, 300)
                    })
                })
        }
        
        function c(e) {
            if ("" != e) {
                MAStatusBar.remove();
                MAStatusBar.add("Selecting shipping method...");
                
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "ePacket";
                
                if (e == "EMS_ZX_ZX_US") e = "ePacket";
                
                var t = [];
                return $(".logistics-delivery")
                    .each(function() {
                        t.push(this)
                    }), t.reduce(function(n, t) {
                        return n.then(function() {
                            return o(t, e)
                        })
                    }, Promise.resolve())
                
            }
        }
        
        function o(t, i) {
            return new Promise(function(e) {
                    $(t)
                        .click(), setTimeout(function() {
                            return e()
                        }, 300)
                })
                .then(function() {
                    return new Promise(function(n) {
                        $(".logistics-list .service-name:contains(" + i + ")")
                            .click(), setTimeout(function() {
                                return n()
                            }, 100)
                    })
                })
                .then(function() {
                    return new Promise(function(n) {
                        $(".next-closeable .next-dialog-footer button")
                            .click(), setTimeout(function() {
                                return n()
                            }, 100)
                    })
                })
               
        }
        

        l(".select-all .next-checkbox-input")
        .then(function() {
            return $(".select-all .next-checkbox-input").click()
        })
        .then(function() {
            return u("#price-overview .next-loading-tip")
        })
        .then(function() {
            return c(d.defaultShipping)
        })
         .then(function() {
            return MAStatusBar.remove(), $('#checkout-button').click();
         });
}

function cartAction() {     
	var e = jQuery(location).attr("href");
	if (e.indexOf("chrmact=clearCart") > -1) {
		 clearCartAndContinue() 
	} else e.indexOf("chrmact=submitCart") > -1 ? submitCart() : chrome.storage.sync.get({
		continueAfterRefresh: !1
	}, function(e) {
		1 == e.continueAfterRefresh && orderProducts()
	})
}
jQuery(document).ready(function() {
	$("body").append(MAMessages.statusBar());
     
       chrome.storage.sync.get({
                orderId: 0,
                orderNumber: "",
                shopName: "",
                orderData: !1,
                defaultShipping: "",
                note: "",
                formFilled: 0,
                countrySet: 0,
                createdAt: 0
            }, function(e) {
                 
                 if (e.orderData == !1) return;
                     
                 if (Date.now() - e.createdAt > 720 * 1000) { //12 min
                         chrome.runtime.sendMessage({
                                action: config.actions.CONTENT_CLEAR_ORDER_DATA
                        });
                        
                        return;    
                 }
                        
                 cartAction();
                 
       });
    
});