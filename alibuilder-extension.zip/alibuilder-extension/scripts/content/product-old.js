(function(){
    var main = {
        productData : false,
        preInit : function(){
            
            var t = jQuery("body");
            t.append(MAMessages.statusBar()),
           
            this.productData = this.getProductData(); 
            this.initPage();   
        },
        initPage : function(){
            var e = this.productData;
           
            document.body.classList.add("ma"), document.body.classList.add("ma-product");
          //  MAHtml.appendHtml(document, document.body, MAMessages.maToast());
            MAHtml.appendHtml(document, document.body, MAMessages.productPushButton());
            
           /* MA_Auth.ensureAuthCookie(function(ma_cookie){
                if (ma_cookie){ */
                     setTimeout(initSync, 3000);                
                    jQuery(document.body).on("click", "#ma-push-button", function(t) {
                        t.preventDefault(), 
                        MAProduct.pushProduct(e.url, e.id, e.thumb, e.price_min, e.price_max, e.title, e.currency)
                    })
               /* }  */
           /* }) */
        },
        getProductData : function(){
            var data = {id : false, url : false, thumb : false, price_min : false, price_max : false, title : false, currency : false};
            
            var formatPrice = function(e){
                return e.replace(/[^0-9.,]\.*/g, '').replace(',','.');   
            }
            
            var i = document.body.querySelector("#hid-product-id");
            data.id =  (i && i.value !== '') ? i.value : false;  
            
            data.url = window.location.href;
            
            i = document.querySelector("span.p-symbol"); 
            data.currency = (i && i.innerText !== '') ? i.innerText : false;  
            
            i = document.querySelector(".product-name");
            data.title =  (i && i.innerText !== '') ? i.innerText : false;
            
            i = document.querySelector(".img-thumb-item img");
            data.thumb = (i && i.src !== '') ? i.src : false;
            
            r = document.querySelector("span.p-price"); 
            if (r && "" !== r.innerText){
                var p = r.innerText.split('-');
                if (p){
                     data.price_min = (typeof p[0] !== 'undefined') ? formatPrice(p[0]) : false;
                     data.price_max = (typeof p[1] !== 'undefined') ? formatPrice(p[1]) : false;
                }
            }
            
            return data; 
            
            
        }
    };
    
    main.preInit();
}());


function initSync() {
    chrome.storage.sync.get({
        orderData: !1,
        currentProduct: 0,
        cartEmpty : !1,
    }, function(t) {
        t.cartEmpty !== !0 && t.orderData !== !1 && t.currentProduct > 0 ? chrome.extension.sendMessage({ action: config.actions.CONTENT_ORDER_FULFILLMENT_TO_CART}) :
        t.orderData !== !1 && t.currentProduct > 0 && addItem(JSON.parse(t.orderData), t.currentProduct-1);
    })
}

function addItem(t, e) {

    var o = 1,
        n = t.products[e],
        r = jQuery(location).attr("href");
    
    if (r.indexOf(n.productId) > -1 && ("undefined" == typeof n.inCart || n.inCart === !1)) {
        if (MAStatusBar.add("Adding product to cart..."), "" != n.sku)
            for (key in n.sku) {
                "sku-" + o + "-" + n.sku[key];
                clickSkuButton(n.sku[key], t), o++;
            }
        setQuantity(n.qty), clickAddToCart(), t.products[e].inCart = !0, chrome.storage.sync.set({
            orderData: JSON.stringify(t)
        }, function() {
            e + 1 < t.products.length ? cartPopup.init(config.actions.CONTENT_ORDER_FULFILLMENT_QUEUE) : cartPopup.init(config.actions.CONTENT_ORDER_FULFILLMENT_TO_CART)  
        })
    }
}

function setQuantity(t) {
    jQuery.contains(document.documentElement, jQuery('input[name="quantity"]')[0]) ? jQuery('input[name="quantity"]').val(t) : _LTracker.push({
        reason: "Quantity field not found",
        body: jQuery("body").html()
    })
}

function clickAddToCart() {
    if (jQuery.contains(document.documentElement, jQuery("#add-to-cart")[0])) document.getElementById("add-to-cart").click();
    else {
        if (!jQuery.contains(document.documentElement, jQuery("#j-add-cart-btn")[0])) return console.log('"Add to cart button not found'), null;
        document.getElementById("j-add-cart-btn").click()
    }
}

function clickSkuButton(t, e) {
    var o = jQuery('*[data-sku-id="' + t + '"]');
    if (console.log(o), 1 == o.length) {
        if (!o.parent().hasClass("active")) {
            var n = o.attr("id");
            console.log(document.getElementById(n));
            document.getElementById(n).click();
            console.log('clicked - ' + n);
        }
    } else console.log('SKU button not found ') + t
}

var cartPopup = {
    action: !1,
    attempts: 0,
    interval: 1500,
    init: function(t) {
        this.action = t, setTimeout($.proxy(this.checkPopup, this), this.interval)
    },
    checkPopup: function() {
        console.log('wait for cart popup to be visible and ' + this.action);
        jQuery(".ui-add-shopcart-dialog").is(":visible") ? this.action !== !1 && chrome.extension.sendMessage({
            action: this.action
        }) : this.attempts < 15 && (this.attempts++, this.init(this.action))
    }
};

            

			