var s = document.createElement('script');
s.src = chrome.extension.getURL("assets/js/scripts/ma_api.js");
document.documentElement.appendChild(s);

var requestHtml = function(t, r) {
 
   chrome.extension.sendMessage({
		action: config.actions.CONTENT_GET_PRODUCT_HTML,
		url: t,
        reqId: r
   }, function(e) {
        
        var responseData = {"html":e.html , "reqId":e.reqId};
        var fetchResponse = new CustomEvent(config.actions.WEB_GET_PRODUCT_HTML_RESPONSE, {"detail":responseData});
        document.dispatchEvent(fetchResponse);  
          
   });
};
/*
chrome.extension.onMessage.addListener(function(t, e, n) {
    "get_order_fulfillment_response" == t.type && 
        document.dispatchEvent( new CustomEvent('get_order_fulfillment_response', {"detail":t.data}) );   
        
});*/

document.addEventListener(config.actions.WEB_SET_ALIEXPRESS_COOKIE_REQUEST, function(event) {
    var data = event.detail;
    chrome.extension.sendMessage({
        action: config.actions.CONTENT_SET_ALIEXPRESS_COOKIE,
        cookie_array: data.cookie_array,
        reqId: data.reqId
    }, function(e) {
        
        var responseData = {"reqId":e.reqId};
        var fetchResponse = new CustomEvent(config.actions.WEB_SET_ALIEXPRESS_COOKIE_RESPONSE, {"detail":responseData});
        document.dispatchEvent(fetchResponse);  
          
   });
});


document.addEventListener(config.actions.WEB_GET_PRODUCT_HTML_REQUEST, function(event) {
	var data = event.detail;
	requestHtml(data.url, data.reqId);
});


document.addEventListener(config.actions.WEB_ORDER_FULFILLMENT_REQUEST, function(event) {
    
    chrome.storage.sync.set({
        currentProduct: 0
    }, function(e) {
        var d = event.detail;
        chrome.extension.sendMessage({
            action: config.actions.CONTENT_ORDER_FULFILLMENT_QUEUE,
            data: d
        });
    });
        
});


document.addEventListener(config.actions.WEB_ORDER_TRACKING_CODE_REQUEST, function(event) {   
    var d = event.detail;
    chrome.extension.sendMessage({
        action: config.actions.CONTENT_ORDER_TRACKING_CODE_REQUEST,
        data: d
    });        
});


chrome.extension.onMessage.addListener(function(t, e, n) {
    config.actions.CONTENT_ORDER_TRACKING_CODE_RESPONSE == t.type && 
        document.dispatchEvent( new CustomEvent(config.actions.WEB_ORDER_TRACKING_CODE_RESPONSE, {"detail":t.data}) );   
        
});

