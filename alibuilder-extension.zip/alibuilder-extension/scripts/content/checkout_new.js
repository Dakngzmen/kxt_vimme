jQuery(function ($) {
    function p(e) {
        return e = JSON.parse(e), e.city = $("<div/>").html(e.city).text(), e.contactName = $("<div/>").html(e.contactName).text(), e.address1 = $("<div/>").html(e.address1).text(), e.address2 = $("<div/>").html(e.address2).text(), e
    }

    function s() {
        return new Promise(function(n, t) {
            var i = setInterval(function() {
                return $(".shipping-info.mini .next-btn")
                    .length ? (clearInterval(i), n(!0)) : $(".shipping-info.mini .mini-title")
                    .length ? (clearInterval(i), n(!0)) : $(".shipping-info").length ? (clearInterval(i), n(!0)) : void 0
            }, 300)
        })
    }
    
    function a() {
        return s()
            .then(function() {
                return new Promise(function(n) {
                    var t = setInterval(function() {
                        
                        if ($(".shipping-info.mini .next-btn")
                            .click(), $(".shipping-info.mini .mini-title")
                            .click(), !$(".shipping-info.mini")
                            .length) return clearInterval(t), n();
                            
                    }, 300)
                })
            })
    }
    
    function f_fl(n, t) {
            var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                input = $(n)[i];
                
                var lastValue = input.value;
                input.value = t;
                var event1 = new Event('input', { bubbles: !0 });
          
                event1.simulated = !0;
         
                var tracker = input._valueTracker;
                if (tracker) {
                  tracker.setValue(lastValue);
                }
                input.dispatchEvent(event1);
        }
    
    function d(n) {
                 
        return new Promise(function(t) {
            var r = document.querySelectorAll(".seller-message .seller-message-title");
            for (var o in r) r[0].click();
            $(".seller-message-input")
                .each(function() {
                    $(this)
                        .find("textarea")[0] && f_fl($(this)
                            .find("textarea")[0], n)
                }), setTimeout(function() {
                    t()
                }, 1e3)
        })
    }
    
    f = function(n) {
        
        function t(n, t){
            f_fl(n, t);
        }
       
        function i(e) {
            return new Promise(function(n, i) {
                return t('[name="contactPerson"]', e.contactName), t('[name="address"]', e.address1), t('[name="address2"]', e.address2), "" == e.zip || "none" == e.zip.toLowerCase() ? t('[name="zip"]', "none") : t('[name="zip"]', e.zip), t('[name="mobileNo"]', e.mobile), n()
            })
        }
        function r() {
            return new Promise(function(n, t) {
                var i = setInterval(function() {
                    $(".next-select-trigger-search input")
                        .attr("aria-valuetext") && (clearInterval(i), setTimeout(function() {
                            return n(!0)
                        }, 300))
                }, 300)
            })
        }
        function o(n) {
            return n = n || "other", n = n.toLowerCase(), new Promise(function(e, n) {
                    setTimeout(function() {
                        return e()
                    }, 1e3)
                })
                .then(function() {
                   $(".next-select-values .country-item")
                        .click(), $(".dropdown-content .country-item .css-" + n)
                        .closest(".next-menu-item")
                        .click()
                })
        }
        function c(n) {
            

            return n = n || "Other", n = (n == "Empty" ? "Other" : n),  new Promise(function(e, n) {
                    setTimeout(function() {
                        return e()
                    }, 1e3)
                })
                .then(function() {
                    return new Promise(function(r) {
                        $(".search-select #province")
                            .length ? (t("#province", n), $("#province").val(n), setTimeout(function() {
                                return r()
                            }, 300)) : ($(".search-select input")
                                .eq(0)
                                .click(), setTimeout(function() {
                                    $('.dropdown-content .next-menu-item[title="' + n + '"]')
                                        .closest(".next-menu-item")
                                        .click()
                                }, 1e3)), setTimeout(function() {
                                return r()
                            }, 2e3)
                    })
                            
                })
        }
        function a(n) {
            
             function cfl(s){
                return s.charAt(0).toUpperCase() + s.slice(1);   
             } 
             
            return n = n || "Other",  n = cfl(n.toLowerCase()), new Promise(function(e, n) {
                    setTimeout(function() {
                        return e()
                    }, 1e3)
                })
                .then(function() {
                    
                     return new Promise(function(r) {
                        $(".search-select #city")
                            .length ? (t("#city", n), $("#city").val(n), setTimeout(function() {
                                return r()
                            }, 2e3)) : ($(".search-select input")
                                .eq(1)
                                .click(), setTimeout(function() {
                                    $('.dropdown-content .next-menu-item[title="' + n + '"]')
                                    .closest(".next-menu-item")
                                    .click()    
                                }, 1e3)), setTimeout(function() {
                                return r()
                            }, 2e3)
                    })
                            
                            
                })
        }
        function s(e) {
            
            return new Promise(function(n, i) {
                return e && t('[name="phoneCountry"]', e),  n()
            })
        }
        function u() {
       
            chrome.storage.sync.set({
                orderData: !1
            });
   
            return new Promise(function(n, t) {
                return $(".save button")
                    .eq(0)
                    .click(), n()
            })
            .then(function(){
                MAStatusBar.remove();
                MAStatusBar.add("Done! Now place your order!");
             
                setTimeout(function() {
                    $(".post-error-msg").html('');
                
                    $(".save button").eq(0).click(); 
                    
                
                    }, 1e3)    
            })
        }
        return function() {
             MAStatusBar.remove();
             MAStatusBar.add("Adding customer shipping details...");
             
                return new Promise(function(n) {
                    return $(".address-add-new>button").length ?
                        $(".address-add-new>button").click() : $('.address-list-opt button[ae_button_type="add_new_address"]').length ?
                        $('.address-list-opt button[ae_button_type="add_new_address"]').click() :
                        $(".shipping-info .next-btn").length ? $(".shipping-info .next-btn").eq(1).click() : void 0, n()
                })
            }()
            .then(function() {
                return r()
            })
            .then(function() {
                return o(n.orderData.countryRegion)
            })
            .then(function() {
                return c(n.orderData.region)
            })
            .then(function() {
                return a(n.orderData.city)
            })
            .then(function() {
                return i(n.orderData)
            })
            .then(function() {
                return s(n.orderData.mobile_code)
            })
            .then(function() {
                return u()
            })
    }
     
        document.body.classList.add("ma");
        document.body.classList.add("ma-checkout");
        
        $("body").append(MAMessages.statusBar());
        
        chrome.storage.sync.get({
                    orderId: 0,
                    orderNumber: "",
                    shopName: "",
                    orderData: !1,
                    defaultShipping: "",
                    note: "",
                    formFilled: 0,
                    countrySet: 0,
                    createdAt: 0
                }, function(e) {
                    
                     if (e.orderData == !1) return;
                     
                     if (Date.now() - e.createdAt > 720 * 1000) { //12 min
                            chrome.runtime.sendMessage({
                                    action: config.actions.CONTENT_CLEAR_ORDER_DATA
                            });
                            
                            return;    
                     }
             
                    MAPromises.clickBtn(".switch-to-full a")
                    .catch(function(e) {})
                    .then(function(){        
                        return a()
                    })
                    .then(function() {
                        
                        
                        return e.orderData = p(e.orderData),
                        
                        
                        MAPromises.waitEl(".seller-message .seller-message-title")
                        .then(function(){
                            MAStatusBar.add("Filling order notes..."); 
                             return d(e.note)
                        }).then(function(){
                             f(e);    
                        })
                    })
        });
        

});