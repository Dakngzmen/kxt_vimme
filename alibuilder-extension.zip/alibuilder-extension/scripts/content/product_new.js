jQuery(function ($) {
    
    var oo = {
       setInput: function(n, t) {
            var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
            
            if (!$(n).length){
                 console.log(n + " field not found");
                 return; 
            }
            
            var r = $(n)[i];
            
            r.value = t, r.defaultValue = t;
            var o = r.value;
            r.value = t, event = new Event("input", {
                bubbles: !0
            }), event.simulated = !0;
            var c = r._valueTracker;
            c && c.setValue(o), r.dispatchEvent(event)
       },
       clickBtn: function(e){
            return MAPromises.clickBtn(e)   
       },
       isEl : function(e){
           return $(e).length > 0 ? !0 : !1
       }
    };
    
    var main = {
        productData : false,
        preInit : function(){
            
            var t = $("body");
            t.append(MAMessages.statusBar());
            main.initPage();

        },
        checkPageHeaders : function(){
            return new Promise(function (j, f) {
                    chrome.storage.sync.get({ respStatus: 200},function(s) {
                        if (s.respStatus == 404) {
                            return f();
                        } else {
                            return j();
                        }
                    });
            });
        },
        initPage : function(){

           
            document.body.classList.add("ma"), document.body.classList.add("ma-product");

            chrome.storage.sync.get({
                    orderData: !1,
                    currentProduct: 0,
                    cartEmpty : !1,
                }, function(t) {

                if (t.orderData !== !1) {
                     o = JSON.parse(t.orderData);
                    e1 = t.currentProduct;
                     n = o.products[e1];
                     r = $(location).attr("href");
                }

                if (t.orderData !== !1 && typeof n !== "undefined" && r.indexOf(n.productId) > -1 ){
                    main.checkPageHeaders().then(function() {
                        main.initSync(t);
                    }).catch(function(){
                        MAOrder.sendStatus({'stage': 21}, function () {
                            MAFunc.goToPluginTab();
                        });

                        MAStatusBar.remove();
                        MAStatusBar.add("Can't add this product to the cart, try do that manually...");
                    });
                } else {

                        main.productData = main.getProductData();
                        var k = main.productData;

                        chrome.runtime.onMessage.addListener(function (t) {
                            if (t.name == config.actions.CONTENT_CHECK_PRODUCTS_IMPORTED) {

                                if (t.status == "OK"){
                                    var e = t.products;
                                    for (var i in e) {
                                        if (e[i].imported) {
                                            MAHtml.appendHtml(document, document.body, MAMessages.productImportedIcon());
                                        } else {
                                            MAHtml.appendHtml(document, document.body, MAMessages.productPushButton());
                                            $(document.body).on("click", "#ma-push-button", function (t) {
                                                t.preventDefault(),
                                                    MAProduct.pushProduct(k.url, k.id, k.thumb, k.price_min, k.price_max, k.title, k.currency).catch(function () {
                                                    });
                                            })
                                        }
                                    }
                                } else {
                                    messagePanel.render({
                                        iconClose : chrome.extension.getURL(config.assets.iconClose),
                                        svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                                        state: MAProduct.getCheckImportedStateData(t)
                                    });
                                }



                            }
                        })

                        chrome.runtime.sendMessage({
                            action: config.actions.CONTENT_CHECK_PRODUCTS_IMPORTED,
                            ids: [k.id]
                        })

                }

            });
        },
        getProductData : function(){
            var data = {id : false, url : false, thumb : false, price_min : false, price_max : false, title : false, currency : false};
            
            var formatPrice = function(e){
                return e.replace(/[^0-9.,]\.*/g, '').replace(',','.');   
            }
            
        
            data.url = window.location.href;
            
            var tmp = data.url.match(/aliexpress\.com\/item.*\/([0-9]+)\.html/);
            data.id = tmp[1];
            
            i = document.querySelector("span.p-symbol"); 
            if (i == null){
                i = document.querySelector('.currency');         
            } 
            
            data.currency = (i && i.innerText !== '') ? i.innerText : false;
             
            i = document.querySelector(".product-name");
            if (i == null){
                i = document.querySelector(".product-title");
            }

            data.title =  (i && i.innerText !== '') ? i.innerText : false;
            
            i = document.querySelector(".img-thumb-item img");
            if (i == null){
               i = document.querySelector('.images-view-list img');
            }
            
            data.thumb = (i && i.src !== '') ? i.src : false;
            
            
            r = document.querySelector("span.p-price"); 
            if (r == null){
                r = document.querySelector(".product-price-value"); 
            }
            
            if (r && "" !== r.innerText){
                var p = r.innerText.split('-');
                if (p){
                     data.price_min = (typeof p[0] !== 'undefined') ? formatPrice(p[0]) : false;
                     data.price_max = (typeof p[1] !== 'undefined') ? formatPrice(p[1]) : false;
                }
            }
            
            return data; 
            
            
        },
        initSync : function(t) {
                function r() {
                    return new Promise(function(n, t) {
                        var i = setInterval(function() {
                            ($("#j-add-cart-btn")
                                .length || $(".addcart").length) && (clearInterval(i), setTimeout(function() {
                                    return n(!0)
                                }, 300))
                        }, 300)
                    })
                }
                
                t.cartEmpty !== !0 && t.orderData !== !1 ? chrome.extension.sendMessage({ action: config.actions.CONTENT_ORDER_FULFILLMENT_TO_CART}) :
                t.orderData !== !1 && r().then(function(){
                        main.addItem(JSON.parse(t.orderData), t.currentProduct);
                })
        },
        markItemAsAdded : function(t,e,f){
            t.products[e].inCart = !0;
            chrome.storage.sync.set({
                currentProduct: e+1,
                orderData: JSON.stringify(t)
            }, function () {
                f();
            });
        },
        allowManualMode : function(t, e){
            main.markItemAsAdded(t, e, function(){
                MAOrder.sendStatus({'stage': 21});
                MAFunc.goToPluginTab();
            })
        },
        addItem : function(t, e) {

            var
                n = t.products[e],
                r = $(location).attr("href");
            
            if (r.indexOf(n.productId) > -1 && ("undefined" == typeof n.inCart || n.inCart === !1)) {

                MAStatusBar.add("Adding product to cart...");

                if ("" != n.sku) {
                    if ($(".addcart").length) {
                        var m = document.documentElement.innerHTML;
                        var d = MAProduct.getAttrValueIndexes(m, n.sku);

                        if (n.sku && d.length == 0) {
                                MAStatusBar.remove();
                                MAStatusBar.add("The given variant doesn't exist. Try to choose another one or add a similar product from another supplier manually.");
                                main.allowManualMode(t,e);

                        } else {

                            function lf(n, f) {
                                for (key in n) {
                                    main.clickSkuButton1(n[key].attrIndex, n[key].valIndex).catch(function () {

                                        MAStatusBar.remove();
                                        MAStatusBar.add("The given variant doesn't exist. Try to choose another one or add a similar product from another supplier manually.");
                                        main.allowManualMode(t,e);
                                        f();
                                    }).then(function () {
                                        delete n[key];
                                        if (Object.keys(n).length > 0) {
                                            lf(n, f);
                                        } else {
                                            f();
                                        }
                                    });

                                    break;

                                }
                            }

                            lf(d, function () {
                                ff();
                            });
                        }

                    } else {
                        MAStatusBar.remove();
                        MAStatusBar.add("We can't find the add-to-cart button. Please contact support.");
                    }
                }
                else {
                    ff();
                }

                function bf(){
                    return new Promise(function (j, f) {
                        setTimeout(function(){
                            if ($('#batman-dialog-wrap').length) {

                                MAOrder.sendStatus({ 'stage':0},function(){
                                    MAFunc.goToPluginTab();
                                });
                                MAStatusBar.remove();
                                MAStatusBar.add("Please login into your AlIExpress account...");

                                var i = setInterval(function () {
                                    return !$('#batman-dialog-wrap').length ? (clearInterval(i), j(!0)) : void 0
                                }, 1000)
                            } else {
                                j(!0)
                            }
                        },1000);
                    })
                }

                function cf(t,e){
                    return new Promise(function (j, f) {
                        setTimeout(function(){
                            if ($('.addcart-balloon').length) {

                                MAStatusBar.remove();
                                MAStatusBar.add("Can't add this product to the cart. Try to choose another one or add a similar product from another supplier manually...");

                                main.allowManualMode(t,e);

                                var i = setInterval(function () {
                                    return !$('.addcart-balloon').length ? (clearInterval(i), f(!0)) : void 0
                                }, 1000)
                            } else {
                                j(!0)
                            }
                        },1000);
                    })
                }

                function ff(){
                    setTimeout(function () {

                        if (main.setQuantity(n.qty) === !1) {
                            MAStatusBar.remove();
                            MAStatusBar.add("Can't add this product to the cart. Try to choose another one or add a similar product from another supplier manually...");
                            main.allowManualMode(t,e);
                            return;
                         }
                        setTimeout(function () {

                            main.clickAddToCart(), t.products[e].inCart = !0;

                            bf()
                                .then(function(){
                                    return cf(t,e);
                                })
                                .catch(function(){
                                    ff();
                                })
                                .then(function(){
                                    MAOrder.sendStatus({'stage':53}, function(){
                                        MAFunc.goToPluginTab();
                                    });


                                    chrome.storage.sync.set({
                                        orderData: JSON.stringify(t)
                                    }, function () {

                                        main.cartPopupPromise().then(function(){
                                           if ( e + 1 < t.products.length )
                                               var act = config.actions.CONTENT_ORDER_FULFILLMENT_QUEUE
                                            else
                                                var act = config.actions.CONTENT_ORDER_FULFILLMENT_TO_CART;

                                            main.markItemAsAdded(t, e, function(){
                                                chrome.extension.sendMessage({
                                                    action: act
                                                })
                                            });
                                        }).catch(function(){
                                            MAStatusBar.remove();
                                            MAStatusBar.add("Can't add this product to the cart. Try to choose another one or add a similar product from another supplier manually.");
                                            main.allowManualMode(t,e);
                                        })

                                    })
                                });


                        }, 1000);

                    }, 1000);

                }

            }
        },
        setQuantity : function(t) {
            
            var q = 'input[name="quantity"]';
            if ($(q).length){
                $(q).val(t)    
            } else if ($('.product-quantity input').length){
                main.setInput($('.product-quantity input'),t);
            }
            else{
                return !1;
            }

            return !0;
        },
        setInput: function(n, t) {
            var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;

            if (!$(n).length){
                console.log(n + " field not found");
                return;
            }

            var r = $(n)[i];

            r.value = t, r.defaultValue = t;
            var o = r.value;
            r.value = t, event = new Event("input", {
                bubbles: !0
            }), event.simulated = !0;
            var c = r._valueTracker;
            c && c.setValue(o), r.dispatchEvent(event)
        },
        clickAddToCart : function() {

            if ($(".addcart").length){

                document.querySelector(".addcart").click();
            }
            else if ($.contains(document.documentElement, $("#add-to-cart")[0])){
                setTimeout(
                    function(){

                        document.getElementById("add-to-cart").click();
                    }, 1000);
            } 
            else {
                if (!$.contains(document.documentElement, $("#j-add-cart-btn")[0])) return console.log('"Add to cart button not found'), null;
                
                setTimeout(
                    function(){

                        document.getElementById("j-add-cart-btn").click();
                    }, 1000);
                
            }

        },
        clickSkuButton1 : function(i,v){
            var e = $('.sku-property ').eq(i).find('.sku-property-item').eq(v);

            return new Promise(function(n, t) {

                if (!e.length) {
                    return t();
                }

                if (e.hasClass('disabled')){
                    return t();
                }

                if (!e.hasClass("selected")) {
                    oo.clickBtn(e).then(function(e){
                        if (!e.hasClass("selected")) {
                            oo.clickBtn(e).then(function(){
                                return n();
                            });

                        } else {
                            return n();
                        }
                    });
                } else {
                    return n();
                }

            });

        },
        clickSkuButton : function(t, e) {
            var c = '*[data-sku-id="' + t + '"]', o = $(c);

            return new Promise(function(n, v) {

                if (!o.length) {
                    return v();
                }

                if (!c.length) {
                    return v();
                }

                if (!o.parent().hasClass("active")) {
                        oo.clickBtn(c).then(function(e){
                            if (!o.parent().hasClass("active")) {
                                oo.clickBtn(c).then(function(){
                                    return n();
                                });

                            } else {
                                return n();
                            }
                        });

                } else {
                        return n();
                }


            });




        },
        cartPopupPromise : function(){
            return new Promise(function (j, f) {
                var attemps = 0, i = setInterval(function () {
                    if ($(".ui-add-shopcart-dialog").is(":visible") || $(".addcart-result-inner").is(":visible") ){
                        clearInterval(i);
                        return j();
                    } else {

                        if ( attempts < 15) {
                            attempts++;
                        }

                        if (attempts >= 15){
                            return f();
                        }

                    }

                }, 1000)
            })
        },
        cartPopup : {
            action: !1,
            action_login_failed: !1,
            attempts: 0,
            interval: 1500,
            init: function(t,f) {
                this.action = t, this.action_login_failed = f, setTimeout($.proxy(this.checkPopup, this), this.interval)
            },
            checkPopup: function() {

                 if ( $(".ui-add-shopcart-dialog").is(":visible") || $(".addcart-result-inner").is(":visible") ) {

                     this.action !== !1 && chrome.extension.sendMessage({
                             action: this.action
                         })
                 } else {

                    if ( this.attempts < 15) {
                        this.attempts++;
                        this.init(this.action);
                    }

                    if (this.attempts >= 15){
                        MAStatusBar.remove();
                        MAStatusBar.add("Can't add this product to the cart. Try to choose another one or add a similar product from another supplier manually.");
                      //  MAOrder.clear();
                    }

                }

            }
        }
    };

    main.preInit();
});
