(function(){
    var main = {
        init : function(){
            var t = jQuery("body");
            t.append(MAMessages.statusBar());
            MAStatusBar.add("Skip promo page...");
            buttonWaiter.init();
        },
        
    };
    
    var buttonWaiter =  {
            attempts: 0,
            interval: 2000,
            init: function() {
                setTimeout($.proxy(this.checkButton, this), this.interval)
            },
            checkButton: function() {
                console.log('wait for View Details button to be visible');
                var el = jQuery("div.view-detail a");
                el.length > 0 ? (document.body.querySelector("div.view-detail a").click(), console.log('the button is found')) : this.attempts < 15 && (this.attempts++, this.init())
            }
        }
    
    
    
    main.init();
}());