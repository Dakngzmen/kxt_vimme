var app = function() {
	var e, t = {
		store: {}
	};
	chrome.extension.getBackgroundPage();
	return {
		init: function() {
			e = this, chrome.extension.sendMessage({
				action: "p_b_getData"
			}, function(e) {}), chrome.extension.onMessage.addListener(function(n, o, i) {
				"b_p_setStore" == n.action && (t.store = n.store, e.setStore())
			}), e.setStore()
		},
		toggle: function() {},
		setStore: function() {}
	}
}();
app.init();