jQuery(function($) {

  var count = 0;
  
  function updateCounter(){
    $('.count').text(count);
    var deleteButton = $('.clear-all');
    if(count === 0){
        deleteButton.attr('disabled', 'disabled').addClass('disabled');
    }
    else{
        deleteButton.removeAttr('disabled').removeClass('disabled');
    }
  }
  
  var saveStore = function(id, content, f){
    
      var id = id;
      
    config.get_ext_options(function(data){
        
        if (id !== null && id in  data.stores){
             data.stores[id] = content;   
        } else
        
        id = 
        data.stores.push({
            value_domain: content.value_domain,
            value_login: content.value_login,
            value_password: content.value_password
        }) - 1;
        
        chrome.storage.sync.set({ stores: data.stores }, function() { f(id) });              
    });
    
  };
  
  var test_connection = function(){
    MA_Auth.testConnection(function(e){
        /*
        var status = document.getElementById('status');
        if (e.status == "ok") status.textContent = 'Auth successeful.';
        else status.textContent = 'Auth failed.';
        setTimeout(function() {
              status.textContent = '';
            }, 750);   */
        
    })  
}
                                       
  var editStore = function(id){
     var store = $('#store' + id),
     html_actions = store.find('.actions');
     
      var edit_button = store.find('.edit-button'); 
      
      store.find('input').each(function(){ $(this).prop( "disabled", false ) });
     
     store.find('.value_domain').focus();
          edit_button.after($('<button />', {
                        "class": "icon-save save-button", 
                         click: function(){
                                  
                                  store.find('input').each(function(){ $(this).prop( "disabled", true ) });
                                    
                                  var content = Object.create(null);
             
                                 content.value_domain = store.find('.value_domain').val(),
                                 content.value_login = store.find('.value_login').val(),
                                 content.value_password = store.find('.value_password').val();
                                 
                                 if (validateStore(content)) { 
                                     content.value_domain = normalizeStoreUrl(content.value_domain); 
                                     var saved = $('.save-notification');
      
                                        config.get_ext_options(function(data){ 
                                           var active_id = data.active_store;      
                                           
                                           saveStore(id, content, function(id){
                                                    if (active_id == id) setActiveStore(id);
                                                    
                                                    saved.show();
                                                   
                                                    setTimeout(function(){
                                                       saved.hide();
                                                    },2000);
                                                    
                                                    store.find('.save-button').remove();
                                                   /* var edit_button = store.find('.edit-button'); */
                                                    edit_button.show();
                                                    edit_button.addClass('icon-pencil');   
                                           })
                                            
                                           
                                        });
                                 }

                        }
                   
                 
           }));                
   };
  
 
   var deleteStore = function(id){
       
     config.get_ext_options(function(data){
        
        var deleted = $('.delete-notification');
        deleted.show();
                                                
        delete data.stores[id];  
        chrome.storage.sync.set({ stores: data.stores }, function() {
           setTimeout(function(){
            deleted.hide();
           },2000);
        });              
    });
     count--;
     updateCounter();
   };
   
   var checkNullStores = function(s, f){

        for(var key in s){
            var content =  s[key];
            if (content == null) {
                s.splice(key, 1);
                checkNullStores(s, f);
            }
                                  
        }
        
        chrome.storage.sync.set({ stores: s }, function() {  f(s) });    
   }
 
   var removeStore = function(id){
      var item = $('#store' + id );
      
               config.get_ext_options(function(data){ 
                    var active_id = data.active_store; 
                    
                    if (active_id == id) setActiveStore(false);
                      item.addClass('removed-item')
                          .one('webkitAnimationEnd oanimationend msAnimationEnd animationend', function(e) {
                              $(this).remove();
                           });

                    deleteStore(id);  
               });
      
    };
   
   var createStore = function(id, content, index){

   $('.form-style-5').hide();

      var fields = '<div class="form-style-5 values" id="store' + id + '"><img src="assets/images/alibuild_logo.png" alt="AliBuilder" style="margin-bottom:1em; color:black;"><fieldset><input type="text" class="value_domain" value="' + content.value_domain + '" disabled><input type="text" class="value_login" value="' + content.value_login + '" disabled><input type="text" class="value_password" value="' + content.value_password + '" disabled></fieldset></div>';
      //var store = '<table id="store' + id + '">' + fields + '</table>';
       var store = fields;   
      
      if(!$('#store'+ id).length){
   
          $('.stores').append( $(store).addClass('new-item')); 
    

          var createdItem = $('#store'+ id);
          

         var html_actions =  $('<div>').appendTo(createdItem);
         
         html_actions = $('<div>').addClass('actions').appendTo( html_actions);
                  
        html_actions.append($('<button />', {
                               "class" :"icon-trash delete-button",
                               "contenteditable" : "false",
                               click: function(){
                                        var confirmation = confirm('Delete this item?');
                                        if(confirmation) {
                                           removeStore(id);
										   $('.form-style-5').show();
										   $('.values').hide();
										}
                                      }
	  
                  })); 

        html_actions.append($('<button />', {
                              "class" :"icon-pencil edit-button",
                              "contenteditable" : "false",
                              click: function(){
                                    //  createdItem.attr('contenteditable', 'true');
                                     createdItem.find('li').each(function(){ $(this).attr('contenteditable', 'true') });
                                      editStore(id);
                                      $(this).hide();
                                      
                                      $(this).removeClass('icon-pencil');
                                     
                              } 
                 }));
                 
                 
                 var active_btn_class_string = "icon-check-empty active-button";
                 if ( typeof content.value_active !== "undefined" && content.value_active === 1  ){              active_btn_class_string = "icon-check active-button";                              
                 }
                 
                 html_actions.append($('<button />', {
                           "class" : active_btn_class_string,
                           "contenteditable" : "false",
                           click: function(){
                               $('.stores').find('.icon-check').each(function(){
                                     $(this).removeClass('icon-check');
                                     $(this).addClass('icon-check-empty');
                                    //$(this).prop('class', "icon-check-empty");
                                }); 
                                
                                $(this).removeClass('icon-check-empty');
                                $(this).addClass('icon-check');
                                
                                //save active
                                setActiveStore(id);
                           }
                 }));
                    
                
                                    
                  
        createdItem.on('keydown', function(ev){
            if(ev.keyCode === 13) return false;
        });
        
        count++;
        updateCounter();
      }
    };

   var handleInput = function(){
          $('#input-form').on('submit', function(event){
             var content = Object.create(null);
                 
                 content.value_domain = $('#domain').val();
                 content.value_login = $('#login').val();
                 content.value_password = $('#password').val();
                 
             if (validateStore(content)) { 
                
                 event.preventDefault();
                 content.value_domain = normalizeStoreUrl(content.value_domain); 
                 saveStore(null, content, function(id){
                      createStore(id, content); 
                      
                      $('#domain').val(''); 
                      $('#login').val(''); 
                      $('#password').val('');    
                  });
             
             } else return false;     
                  
                 
              
          });
     };
     
   var validateStore = function(content){
         var is_error = false, error_msg = '';
          
                 if (content.value_domain == '' || content.value_login == '' || content.value_password == '' ){
                    is_error = true;
                    error_msg = 'Error! Please fill out all fields to add new store.';      
                 }
                 
                 var url = content.value_domain;
                 
                 if (  url !== '' && url.indexOf('wp-admin' ) !== -1 || url.indexOf('wp-login' ) !== -1 ){
                     
                    is_error = true;
                    error_msg = 'Error! Please check "Your Website url" field. It should not contain wp-admin or wp-login substrings.';
         
                 }
     
         if (is_error) alert(error_msg);
         
        return !is_error;    
     }
   
   var normalizeStoreUrl = function(url){
        url = url.replace(/\/*$/, '/'); 
        return url;   
   } 
    
   var markActiveStore = function(id){  
            if ( $('.stores').find('.icon-check').length < 1 )
            $('.stores').find('.icon-check-empty:eq('+id+')')
            .removeClass('icon-check-empty')
            .addClass('icon-check');   
  
    }
    
    var setActiveStore = function(id){
        
        config.get_ext_options(function(data){
            MA_Auth.resetAuthCookie(function(){
                if (id !== null && id in data.stores){
                     var s = data.stores[id]; 
                     
                     chrome.storage.sync.set({ root_url: s.value_domain, username : s.value_login, password : s.value_password, active_store: id }, function() {  test_connection(); });               
                } else {
                    
                    chrome.storage.sync.set({ root_url: false, username : false, password : false, active_store: false }, function() { /*f(s)*/ });      
                        
                }    
            });
            
            
            
        });
      
    }
  
    var loadStores = function(){

    config.get_ext_options(function(data){
        if(data.stores.length == 0 && data.root_url){
            data.stores.push({
                value_domain: data.root_url,
                value_login: data.username,
                value_password: data.password
            });
            
            chrome.storage.sync.set({ stores: data.stores, active_store: 0 }, function() { });
        }
        
        
        
        
        if(data.stores.length!==0){
             checkNullStores(data.stores, function(s){                
                if(s.length!==0){
                    
                    for(var key in s){
                        var content =  s[key];
                        if (content !== null) createStore(key, content);
                                  
                    }
                   
                    var act_ind = data.active_store; 
                    if (act_ind == false || typeof data.stores[act_ind] == "undefined") {
                        act_ind = 0;
                        setActiveStore(act_ind);
                    }
                    markActiveStore(act_ind);
                }    
             });
             
        }
       
    });
   
     };
 
    var handleDeleteButton = function(){
          $('.clear-all').on('click', function(){
            if(confirm('Are you sure you want to delete the item in the list? There is no turning back after that.')){                 //remove items from DOM
              var items = $('tr[id ^= store]');
              items.addClass('removed-item').one('webkitAnimationEnd oanimationend msAnimationEnd animationend', function(e) {
                $(this).remove();
				$('.form-style-5').show();
             });

 
              chrome.storage.sync.set({  root_url: false,
                username: false,
                password: false,
                stores: [],
                active_store: false }, function() { });
             
              count = 0;
              updateCounter();
            }
          });
      };
  
    var init = function(){
           $('#text').focus();
           loadStores();
           handleDeleteButton();
           handleInput();
           updateCounter();
    };

  init();

});   