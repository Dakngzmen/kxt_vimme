var config = {
        get_ext_options : function(f){
             chrome.storage.sync.get({
                root_url: false,
                username: false,
                password: false,
                stores: [],
                active_store: false,
                shippingOption: config.defaultShippingSettings.shippingOption,
                shippingCountry: config.defaultShippingSettings.shippingCountry,
                shippingCurrency: config.defaultShippingSettings.shippingCurrency,
                showShipping: !0,
                showOnlyActive: !1,
                showProcessing: !0
                
              }, function(items) {
                  f(items);
              });     
        },
        defaults: {
            storedOrderTTL: 6e5,
            processingOrderTTL: 6e4,
            maxFulfilledOrders: 30,
            minPageMatchPercentage: .5,
            aliProductLink: "//www.aliexpress.com/item/slug/{0}.html",
            failedTaskPause: 150,
            chromeExtensionSource: 4,
        },
        assets: {
            svgLogo: "assets/images/logo.png",
            logoSM: "assets/images/logo-small.png",
            logoXS: "assets/images/logo-xs.png",
            iconImportSuccess: "assets/images/icon-import-success.png",
            iconImportError: "assets/images/icon-import-error.png",
            iconTime: "assets/images/icon-time.png",
            iconCheck: "assets/images/icon-check.png",
            iconClose: "assets/images/icon-close.png",
            iconCloseCircle: "assets/images/icon-close-circle.png",
            iconRemove: "assets/images/icon-x.png",
            btnFloating: "assets/images/btn-floating.png",
        },
        urls: {
            shippingInfo_old: "https://freight.aliexpress.com/ajaxFreightCalculateService.htm?productid={1}&country={2}&count={3}&currencyCode={4}",
            shippingInfo_old1: "https://m.aliexpress.com/freight/ajaxapi/calculate.do?productId={1}&countryCode={2}&quantity={3}&currency={4}",
            shippingInfo: "https://freight.aliexpress.com/ajaxFreightCalculateService.htm?productid={1}&country={2}&count={3}&currencyCode={4}",
            aliexpressLink : "https://www.aliexpress.com/",
            orderInfo : "https://trade.aliexpress.com/order_detail.htm?orderId={1}&rrnd={2}",
            aliexpressPayAllLink : "https://trade.aliexpress.com/order_list.htm",
            aliexpressMaintain : "https://www.aliexpress.com/maintain.html",
            queryCountries: "https://ilogisticsaddress.aliexpress.com/AjaxQueryCountries",
            ordersDetail: "https://shoppingcart.aliexpress.com/api/1.0/orders.htm",
            ajaxSaveOrUpdateBuyerAddress: "https://ilogisticsaddress.aliexpress.com/ajaxSaveOrUpdateBuyerAddress.htm"
        },
        actions: {
            SYNC_PRODUCT_LIST : "SYNC_PRODUCT_LIST",
            CONTENT_PUSH_PRODUCT_TO_APP : "CONTENT_PUSH_PRODUCT_TO_APP", 
            CONTENT_DELETE_PRODUCT_FROM_APP : "CONTENT_DELETE_PRODUCT_FROM_APP",
            CONTENT_TEST_CONNECTION : "CONTENT_TEST_CONNECTION",
            /*
            CONTENT_GENERATE_AUTH_COOKIE: "CONTENT_GENERATE_AUTH_COOKIE",
            CONTENT_VALIDATE_AUTH_COOKIE: "CONTENT_VALIDATE_AUTH_COOKIE",
            */
            CONTENT_OPEN_SETTING_TAB : "CONTENT_OPEN_SETTING_TAB",
            GET_PRODUCTS_SHIPPING_INFO : "GET_PRODUCTS_SHIPPING_INFO", 
            GET_AND_PUSH_PRODUCT_HTML_TO_APP : "GET_AND_PUSH_PRODUCT_HTML_TO_APP",
            CONTENT_GET_PRODUCT_HTML : "CONTENT_GET_PRODUCT_HTML",
            CONTENT_ORDER_FULFILLMENT_QUEUE : "OrderFulfillmentQueue",
            CONTENT_ORDER_TRACKING_CODE_REQUEST : "CONTENT_ORDER_TRACKING_CODE_REQUEST",
            CONTENT_ORDER_TRACKING_CODE_RESPONSE : "CONTENT_ORDER_TRACKING_CODE_RESPONSE",
            CONTENT_ORDER_FULFILLMENT_STATUS_RESPONSE : "CONTENT_ORDER_FULFILLMENT_STATUS_RESPONSE",
            CONTENT_SET_ALIEXPRESS_COOKIE : "CONTENT_SET_ALIEXPRESS_COOKIE",
            CONTENT_ORDER_FULFILLMENT_TO_CART : "toCart",
            WEB_GET_PRODUCT_HTML_REQUEST : "WEB_GET_PRODUCT_HTML_REQUEST",
            WEB_GET_PRODUCT_HTML_RESPONSE : "WEB_GET_PRODUCT_HTML_RESPONSE",
            WEB_SET_ALIEXPRESS_COOKIE_REQUEST : "WEB_SET_ALIEXPRESS_COOKIE_REQUEST",
            WEB_SET_ALIEXPRESS_COOKIE_RESPONSE : "WEB_SET_ALIEXPRESS_COOKIE_RESPONSE",
            WEB_ORDER_FULFILLMENT_REQUEST : "order_fulfillment", 
            WEB_ORDER_TRACKING_CODE_REQUEST : "order_tracking_code", 
            WEB_ORDER_TRACKING_CODE_RESPONSE : "order_tracking_code_response",
            WEB_ORDER_FULFILLMENT_STATUS_RESPONSE : "order_fulfillment_status_response",
            CONTENT_CLEAR_ORDER_DATA : "CONTENT_CLEAR_ORDER_DATA",
            CONTENT_ORDER_FULFILLMENT_RESPONSE : "get_order_fulfillment_response",
            WEB_ORDER_FULFILLMENT_PAYALL_REQUEST : "order_fulfillment_payall",
            CONTENT_ORDER_FULFILLMENT_PAYALL_REQUEST : "CONTENT_ORDER_FULFILLMENT_PAYALL_REQUEST",
            WEB_CLOSE_CHROME_TAB_REQUEST : "close_chrome_tab",
            CONTENT_CLOSE_CHROME_TAB_REQUEST : "CONTENT_CLOSE_CHROME_TAB_REQUEST",
            WEB_SWITCH_TO_CHROME_TAB_REQUEST : "switch_to_chrome_tab",
            CONTENT_SWITCH_TO_CHROME_TAB_REQUEST : "SWITCH_TO_CHROME_TAB_REQUEST",
            CONTENT_SWITCH_TO_PLUGIN_TAB_REQUEST : "CONTENT_SWITCH_TO_PLUGIN_TAB_REQUEST",
            CONTENT_SET_ADDRESS : "CONTENT_SET_ADDRESS",
            CONTENT_TEST_REQUEST : "CONTENT_TEST_REQUEST"
        },
        defaultShippingSettings: {
            showShipping: !0,
            shippingOption: "ePacket",
            shippingCountry: "US",
            shippingCurrency: "USD",
            showOnlyActive: !1,
            showProcessing: !0
        },
        shippingOptions: [{
            v: "CAINIAO_STANDARD",
            t: "AliExpress Standard Shipping"
        }, {
            v: "CPAM",
            t: "China Post Registered Air Mail"
        }, {
            v: "EMS",
            t: "EMS"
        }, {
            v: "EMS_ZX_ZX_US",
            t: "ePacket"
        }, {
            v: "DHL",
            t: "DHL"
        }, {
            v: "FEDEX",
            t: "FedEx"
        }, {
            v: "SGP",
            t: "Singapore Post"
        }, {
            v: "TNT",
            t: "TNT"
        }, {
            v: "UPS",
            t: "UPS"
        }, {
            v: "USPS",
            t: "USPS"
        }],
        shippingCurrencies: ["EUR", "GBP", "USD"],
        shippingCountries: [{
            v: "AF",
            t: "Afghanistan"
        }, {
            v: "ALA",
            t: "Aland Islands"
        }, {
            v: "AL",
            t: "Albania"
        }, {
            v: "GBA",
            t: "Alderney"
        }, {
            v: "DZ",
            t: "Algeria"
        }, {
            v: "AS",
            t: "American Samoa"
        }, {
            v: "AD",
            t: "Andorra"
        }, {
            v: "AO",
            t: "Angola"
        }, {
            v: "AI",
            t: "Anguilla"
        }, {
            v: "AQ",
            t: "Antarctica"
        }, {
            v: "AG",
            t: "Antigua and Barbuda"
        }, {
            v: "AR",
            t: "Argentina"
        }, {
            v: "AM",
            t: "Armenia"
        }, {
            v: "AW",
            t: "Aruba"
        }, {
            v: "ASC",
            t: "Ascension Island"
        }, {
            v: "AU",
            t: "Australia"
        }, {
            v: "AT",
            t: "Austria"
        }, {
            v: "AZ",
            t: "Azerbaijan"
        }, {
            v: "BH",
            t: "Bahrain"
        }, {
            v: "GGY",
            t: "Bailiwick of Guernsey"
        }, {
            v: "BD",
            t: "Bangladesh"
        }, {
            v: "BB",
            t: "Barbados"
        }, {
            v: "BY",
            t: "Belarus"
        }, {
            v: "BE",
            t: "Belgium"
        }, {
            v: "BZ",
            t: "Belize"
        }, {
            v: "BJ",
            t: "Benin"
        }, {
            v: "BM",
            t: "Bermuda"
        }, {
            v: "BT",
            t: "Bhutan"
        }, {
            v: "BO",
            t: "Bolivia"
        }, {
            v: "BA",
            t: "Bosnia and Herzegovina"
        }, {
            v: "BW",
            t: "Botswana"
        }, {
            v: "BV",
            t: "Bouvet Island"
        }, {
            v: "BR",
            t: "Brazil"
        }, {
            v: "IO",
            t: "British Indian Ocean Territory"
        }, {
            v: "VG",
            t: "British Virgin Islands"
        }, {
            v: "BG",
            t: "Bulgaria"
        }, {
            v: "BF",
            t: "Burkina Faso"
        }, {
            v: "BI",
            t: "Burundi"
        }, {
            v: "KH",
            t: "Cambodia"
        }, {
            v: "CM",
            t: "Cameroon"
        }, {
            v: "CA",
            t: "Canada"
        }, {
            v: "IC",
            t: "Canary Islands"
        }, {
            v: "CV",
            t: "Cape Verde"
        }, {
            v: "BQ",
            t: "Caribbean Netherlands"
        }, {
            v: "KY",
            t: "Cayman Islands"
        }, {
            v: "CF",
            t: "Central African Republic"
        }, {
            v: "TD",
            t: "Chad"
        }, {
            v: "CL",
            t: "Chile"
        }, {
            v: "CN",
            t: "China"
        }, {
            v: "CX",
            t: "Christmas Island"
        }, {
            v: "CC",
            t: "Cocos (Keeling) Islands"
        }, {
            v: "CO",
            t: "Colombia"
        }, {
            v: "KM",
            t: "Comoros"
        }, {
            v: "CK",
            t: "Cook Islands"
        }, {
            v: "CR",
            t: "Costa Rica"
        }, {
            v: "CI",
            t: "Cote D'Ivoire"
        }, {
            v: "HR",
            t: "Croatia"
        }, {
            v: "CU",
            t: "Cuba"
        }, {
            v: "CW",
            t: "Curacao"
        }, {
            v: "CY",
            t: "Cyprus"
        }, {
            v: "CZ",
            t: "Czech Republic"
        }, {
            v: "DK",
            t: "Denmark"
        }, {
            v: "DJ",
            t: "Djibouti"
        }, {
            v: "DM",
            t: "Dominica"
        }, {
            v: "DO",
            t: "Dominican Republic"
        }, {
            v: "EC",
            t: "Ecuador"
        }, {
            v: "EG",
            t: "Egypt"
        }, {
            v: "SV",
            t: "El Salvador"
        }, {
            v: "GQ",
            t: "Equatorial Guinea"
        }, {
            v: "ER",
            t: "Eritrea"
        }, {
            v: "EE",
            t: "Estonia"
        }, {
            v: "ET",
            t: "Ethiopia"
        }, {
            v: "FK",
            t: "Falkland Islands (Islas Malvinas)"
        }, {
            v: "FO",
            t: "Faroe Islands"
        }, {
            v: "FJ",
            t: "Fiji"
        }, {
            v: "FI",
            t: "Finland"
        }, {
            v: "FR",
            t: "France"
        }, {
            v: "PF",
            t: "French Polynesia"
        }, {
            v: "TF",
            t: "French Southern Territories"
        }, {
            v: "GA",
            t: "Gabon"
        }, {
            v: "GM",
            t: "Gambia"
        }, {
            v: "GE",
            t: "Georgia"
        }, {
            v: "DE",
            t: "Germany"
        }, {
            v: "GH",
            t: "Ghana"
        }, {
            v: "GI",
            t: "Gibraltar"
        }, {
            v: "GR",
            t: "Greece"
        }, {
            v: "GL",
            t: "Greenland"
        }, {
            v: "GD",
            t: "Grenada"
        }, {
            v: "GP",
            t: "Guadeloupe"
        }, {
            v: "GU",
            t: "Guam"
        }, {
            v: "GT",
            t: "Guatemala"
        }, {
            v: "GN",
            t: "Guinea"
        }, {
            v: "GW",
            t: "Guinea-Bissau"
        }, {
            v: "GY",
            t: "Guyana"
        }, {
            v: "GF",
            t: "Guyane French"
        }, {
            v: "HT",
            t: "Haiti"
        }, {
            v: "HN",
            t: "Honduras"
        }, {
            v: "HK",
            t: "Hong Kong"
        }, {
            v: "HU",
            t: "Hungary"
        }, {
            v: "IS",
            t: "Iceland"
        }, {
            v: "IN",
            t: "India"
        }, {
            v: "ID",
            t: "Indonesia"
        }, {
            v: "IQ",
            t: "Iraq"
        }, {
            v: "IE",
            t: "Ireland"
        }, {
            v: "IR",
            t: "Islamic Republic of Iran"
        }, {
            v: "IM",
            t: "Isle of Man"
        }, {
            v: "IL",
            t: "Israel"
        }, {
            v: "IT",
            t: "Italy"
        }, {
            v: "JM",
            t: "Jamaica"
        }, {
            v: "JP",
            t: "Japan"
        }, {
            v: "JEY",
            t: "Jersey"
        }, {
            v: "JO",
            t: "Jordan"
        }, {
            v: "KZ",
            t: "Kazakhstan"
        }, {
            v: "KE",
            t: "Kenya"
        }, {
            v: "KI",
            t: "Kiribati"
        }, {
            v: "KR",
            t: "Korea"
        }, {
            v: "KS",
            t: "Kosovo"
        }, {
            v: "KW",
            t: "Kuwait"
        }, {
            v: "KG",
            t: "Kyrgyzstan"
        }, {
            v: "LA",
            t: "Lao People's Democratic Republic"
        }, {
            v: "LV",
            t: "Latvia"
        }, {
            v: "LB",
            t: "Lebanon"
        }, {
            v: "LS",
            t: "Lesotho"
        }, {
            v: "LR",
            t: "Liberia"
        }, {
            v: "LY",
            t: "Libya"
        }, {
            v: "LI",
            t: "Liechtenstein"
        }, {
            v: "LT",
            t: "Lithuania"
        }, {
            v: "LU",
            t: "Luxembourg"
        }, {
            v: "MO",
            t: "Macau"
        }, {
            v: "MK",
            t: "Macedonia"
        }, {
            v: "MG",
            t: "Madagascar"
        }, {
            v: "MW",
            t: "Malawi"
        }, {
            v: "MY",
            t: "Malaysia"
        }, {
            v: "MV",
            t: "Maldives"
        }, {
            v: "ML",
            t: "Mali"
        }, {
            v: "MT",
            t: "Malta"
        }, {
            v: "MQ",
            t: "Martinique"
        }, {
            v: "MR",
            t: "Mauritania"
        }, {
            v: "MU",
            t: "Mauritius"
        }, {
            v: "YT",
            t: "Mayotte"
        }, {
            v: "MX",
            t: "Mexico"
        }, {
            v: "FM",
            t: "Micronesia"
        }, {
            v: "MC",
            t: "Monaco"
        }, {
            v: "MN",
            t: "Mongolia"
        }, {
            v: "MNE",
            t: "Montenegro"
        }, {
            v: "MS",
            t: "Montserrat"
        }, {
            v: "MA",
            t: "Morocco"
        }, {
            v: "MZ",
            t: "Mozambique"
        }, {
            v: "MM",
            t: "Myanmar"
        }, {
            v: "NA",
            t: "Namibia"
        }, {
            v: "NR",
            t: "Nauru"
        }, {
            v: "BN",
            t: "Negara Brunei Darussalam"
        }, {
            v: "NP",
            t: "Nepal"
        }, {
            v: "NL",
            t: "Netherlands"
        }, {
            v: "AN",
            t: "Netherlands Antilles"
        }, {
            v: "NC",
            t: "New Caledonia"
        }, {
            v: "NZ",
            t: "New Zealand"
        }, {
            v: "NI",
            t: "Nicaragua"
        }, {
            v: "NE",
            t: "Niger"
        }, {
            v: "NG",
            t: "Nigeria"
        }, {
            v: "NU",
            t: "Niue"
        }, {
            v: "NF",
            t: "Norfolk Island"
        }, {
            v: "KP",
            t: "North Korea"
        }, {
            v: "MP",
            t: "Northern Mariana Islands"
        }, {
            v: "NO",
            t: "Norway"
        }, {
            v: "OM",
            t: "Oman"
        }, {
            v: "PK",
            t: "Pakistan"
        }, {
            v: "PW",
            t: "Palau"
        }, {
            v: "PS",
            t: "Palestine"
        }, {
            v: "PA",
            t: "Panama"
        }, {
            v: "PG",
            t: "Papua New Guinea"
        }, {
            v: "PY",
            t: "Paraguay"
        }, {
            v: "PE",
            t: "Peru"
        }, {
            v: "PH",
            t: "Philippines"
        }, {
            v: "PN",
            t: "Pitcairn Islands"
        }, {
            v: "PL",
            t: "Poland"
        }, {
            v: "PT",
            t: "Portugal"
        }, {
            v: "PR",
            t: "Puerto Rico"
        }, {
            v: "QA",
            t: "Qatar"
        }, {
            v: "MD",
            t: "Republic of Moldova"
        }, {
            v: "RE",
            t: "Reunion"
        }, {
            v: "RO",
            t: "Romania"
        }, {
            v: "RU",
            t: "Russian Federation"
        }, {
            v: "RW",
            t: "Rwanda"
        }, {
            v: "BLM",
            t: "Saint Barthelemy"
        }, {
            v: "SH",
            t: "Saint Helena"
        }, {
            v: "KN",
            t: "Saint Kitts and Nevis"
        }, {
            v: "LC",
            t: "Saint Lucia"
        }, {
            v: "MF",
            t: "Saint Martin（France）"
        }, {
            v: "PM",
            t: "Saint Pierre and Miquelon"
        }, {
            v: "VC",
            t: "Saint Vincent and the Grenadines"
        }, {
            v: "WS",
            t: "Samoa"
        }, {
            v: "SM",
            t: "San Marino"
        }, {
            v: "ST",
            t: "Sao Tome and Principe"
        }, {
            v: "SA",
            t: "Saudi Arabia"
        }, {
            v: "SN",
            t: "Senegal"
        }, {
            v: "SRB",
            t: "Serbia"
        }, {
            v: "SC",
            t: "Seychelles"
        }, {
            v: "SL",
            t: "Sierra Leone"
        }, {
            v: "SG",
            t: "Singapore"
        }, {
            v: "SX",
            t: "Sint Maarten (Netherlands)"
        }, {
            v: "SK",
            t: "Slovakia"
        }, {
            v: "SI",
            t: "Slovenia"
        }, {
            v: "SB",
            t: "Solomon Islands"
        }, {
            v: "SO",
            t: "Somalia"
        }, {
            v: "ZA",
            t: "South Africa"
        }, {
            v: "SGS",
            t: "South Georgia and The South Sandwich Islands"
        }, {
            v: "SS",
            t: "South Sudan"
        }, {
            v: "ES",
            t: "Spain"
        }, {
            v: "LK",
            t: "Sri Lanka"
        }, {
            v: "SD",
            t: "Sudan"
        }, {
            v: "SR",
            t: "Suriname"
        }, {
            v: "SJ",
            t: "Svalbard and Jan Mayen"
        }, {
            v: "SZ",
            t: "Swaziland"
        }, {
            v: "SE",
            t: "Sweden"
        }, {
            v: "CH",
            t: "Switzerland"
        }, {
            v: "SY",
            t: "Syrian Arab Republic"
        }, {
            v: "TW",
            t: "Taiwan"
        }, {
            v: "TJ",
            t: "Tajikistan"
        }, {
            v: "HM",
            t: "Territory of Heard Island and McDonald Islands"
        }, {
            v: "TH",
            t: "Thailand"
        }, {
            v: "BS",
            t: "The Commonwealth of The Bahamas"
        }, {
            v: "ZR",
            t: "The Democratic Republic Of The Congo"
        }, {
            v: "CG",
            t: "The Republic of Congo"
        }, {
            v: "MH",
            t: "The Republic of Marshall Islands"
        }, {
            v: "VA",
            t: "The Vatican City State"
        }, {
            v: "TLS",
            t: "Timor-Leste"
        }, {
            v: "TG",
            t: "Togo"
        }, {
            v: "TK",
            t: "Tokelau"
        }, {
            v: "TO",
            t: "Tonga"
        }, {
            v: "TT",
            t: "Trinidad and Tobago"
        }, {
            v: "TN",
            t: "Tunisia"
        }, {
            v: "TR",
            t: "Turkey"
        }, {
            v: "TM",
            t: "Turkmenistan"
        }, {
            v: "TC",
            t: "Turks and Caicos Islands"
        }, {
            v: "TV",
            t: "Tuvalu"
        }, {
            v: "VI",
            t: "U.S.Virgin Islands"
        }, {
            v: "UG",
            t: "Uganda"
        }, {
            v: "UA",
            t: "Ukraine"
        }, {
            v: "AE",
            t: "United Arab Emirates"
        }, {
            v: "UK",
            t: "United Kingdom"
        }, {
            v: "TZ",
            t: "United Republic of Tanzania"
        }, {
            v: "US",
            t: "United States"
        }, {
            v: "UM",
            t: "United States Minor Outlying Islands"
        }, {
            v: "UY",
            t: "Uruguay"
        }, {
            v: "UZ",
            t: "Uzbekistan"
        }, {
            v: "VU",
            t: "Vanuatu"
        }, {
            v: "VE",
            t: "Venezuela"
        }, {
            v: "VN",
            t: "Vietnam"
        }, {
            v: "WF",
            t: "Wallis And Futuna"
        }, {
            v: "EH",
            t: "Western sahara"
        }, {
            v: "YE",
            t: "Yemen"
        }, {
            v: "ZM",
            t: "Zambia"
        }, {
            v: "EAZ",
            t: "Zanzibar"
        }, {
            v: "ZW",
            t: "Zimbabwe"
        }],
        countryMapping: {
            GB: "UK",
            AX: "ALA",
            CG: "CG",
            CD: "CG",
            JE: "JEY",
            KV: "KS",
            ME: "MNE",
            RS: "SRB",
            GS: "SGS",
            BL: "BLM"
        },
        api: {
            root_url: "http://plugins.ru/",
            product_list_url_part : "wp-admin/admin.php?page=alibuilder_main",
            generateAuthCookie : "?ali-json=auth/generate_auth_cookie",
            validateAuthCookie : "?ali-json=auth/validate_auth_cookie", 
            importList: "?ali-json=get_products", 
            productImport: "?ali-json=add_product", 
            productImportUpdate: "?ali-json=upd_product", 
            productDelete: "?ali-json=del_product", 
            getSettings: "?ali-json=get_settings", 
            orderSync: "?ali-json=upd_order"
    },
}
 
var mainPanel = {
    init : function(is_s){
        var i = document.querySelector("body");
        i && i.addEventListener("click", function (e) {
            if (e.target.id == 'ma-import-all' ){
                e.preventDefault();
                var p = [];

                if (!is_s){
                    var l = mainPanel.getAliRunParams();

                    if (l !== false && l.items){
                        p = mainPanel.build_products_array2(l.items, p);

                    } else {
                        console.log('can`t find items in run params');
                    }
                } else {
                    l =  document.querySelector(".items-list");
                    if (l) p = mainPanel.build_products_array(l, p);
                }

                MAProduct.pushProductArr(p);

/*
                setTimeout(function(){
                    var p = [];
                    l = document.querySelectorAll("ul.list-items li");
                    if (l) p = mainPanel.build_products_array(l, p, !0);

                    l = document.querySelector("ul#list-items") ? document.querySelector("ul#list-items") : ( document.querySelector(".items-list") ? document.querySelector(".items-list") : document.querySelectorAll("ul.list-items li") );
                    if (l) p = mainPanel.build_products_array(l, p);

                    l = document.querySelector("ul#hs-list-items");
                    if (l) p = mainPanel.build_products_array(l, p);

                    l = document.querySelector("#hs-below-list-items ul");
                    if (l) p = mainPanel.build_products_array(l, p);

                    l = document.querySelector("ul.son-list");
                    if (l) p = mainPanel.build_products_array(l, p);


                    MAProduct.pushProductArr( p )
                },500);*/
            }
        })    
        
    },
    checkMassImportPossible : function(){
        if ($(".items-list").length || $('script:not([src]):contains("window.runParams")').length) return !0;
        else false;
    },
    getAliRunParams : function(){
        var d = $('script:not([src]):contains("window.runParams")');
        if (d.length > 0) {
            const regex = /^.*window\.runParams = (.*);\n/gm;

            var m, r = [];

            while ((m = regex.exec(d.html())) !== null) {
                if (m.index === regex.lastIndex) {
                    regex.lastIndex++;
                }
                r.push(m);
            }

            if (r && r.length > 1) {
                return JSON.parse(r[1][1])
            } else {
                console.log('run params format is changed');
            }
        } else {
            console.log('can`t find run params');
        }

        return false;

    },	
    build_products_array : function(l, p, skip_child){
                var e = l;

                if (typeof skip_child == "undefined" || skip_child !== !0){
                    e = l.children;
                }

                for (var t = 0; t < e.length; t += 1) {
                    var r = e[t];
                    d = mainPanel.getProductData(r);
                    p.push( d );
                    
                }           
           return p; 
       },
    build_products_array2 : function(l, p){

        for (var t = 0; t < l.length; t += 1) {
            var r = l[t];
            d = mainPanel.getProductData2(r);
            p.push( d );

        }
        return p;
    },
    getProductData2 : function(e){
        var eo = mainPanel;
        var data = {id : false, url : false, thumb : false, price_min : false, price_max : false, title : false, currency : false};

        var formatPrice = function(e){
            return e.replace(/[^0-9.,]\.*/g, '').replace(',','.');

        }

        data.id = e.productId;
        data.url = e.productDetailUrl;
        data.title =  e.title;
        data.thumb = e.imageUrl;

        var p = e.price.split('-');
        if (p){
            data.price_min = (typeof p[0] !== 'undefined') ? formatPrice(p[0]) : false;
            data.price_max = (typeof p[1] !== 'undefined') ? formatPrice(p[1]) : false;
        }

        data.currency = eo.getCurrency();

        return data;

    } ,
    getProductData : function(e){
        var eo = mainPanel;

        var data = {id : false, url : false, thumb : false, price_min : false, price_max : false, title : false, currency : false};

        var formatPrice = function(e){
            return e.replace(/[^0-9.,]\.*/g, '').replace(',','.');

        }

        r = $(e).find('h3 a');

        if (r.length) {
            data.url = r.attr('href');

            r = $(e).find('a[title]').attr('title');
            if (r){
                data.title =  r;
            }
        }
        else {
            r = $(e).find('a.item-title');
            if (r.length) {
                data.url = r.attr('href');
                data.title = r.attr('title');
            }
        }

        if (typeof data.url.match === "undefined"){
            //console.log($(e));
            return false;
        }

        var tmp = data.url.match(/.+\/([0-9,_]+)\.html/mi);

        if (tmp) {
            var p = tmp[1], s = p.split('_');
            if (s.length > 1){
                data.id = s[1];
            } else {
                data.id = s[0];
            }
        }


        r = $(e).find('.pic img');
        if (r.length && "" !== r[0].src) data.thumb = r[0].src;
        else {
            r = $(e).find('.product-img img');
            if (r.length && "" !== r[0].src) data.thumb = r[0].src;
        }


        r = $(e).find('.cost').length ? $(e).find('.cost') : $(e).find('.price-current');

        if (r.length && "" !== r[0].innerText){
            var p = r[0].innerText.split('-');
            if (p){
                data.price_min = (typeof p[0] !== 'undefined') ? formatPrice(p[0]) : false;
                data.price_max = (typeof p[1] !== 'undefined') ? formatPrice(p[1]) : false;
            }

            data.currency = eo.getCurrency();
        }

        return data;
    },
    getCurrency : function(e){
        return document.querySelector("span.currency").innerText
    },  
    render : function() {
        if (mainPanel.checkMassImportPossible()) {
            if (window.location.href.indexOf("/store/") > -1) mainPanel.init(!0);
            else mainPanel.init();


            t = '<div id="ma-main-panel"><button id="ma-import-all">Import all products</button></div>';

            MAHtml.prependHtml(document, document.body, t);
        }
    }  
}
   
var messagePanel = {
    iconClose : '', svgLogo : '', state : '', isBusy : false,
    init : function(t){
        messagePanel.isBusy = t.state.isBusy;
        messagePanel.iconClose = t.iconClose; 
        messagePanel.svgLogo = t.svgLogo;  
        messagePanel.state = t.state;
        
        messagePanel.remove();
  
        var i = document.querySelector("body");
        i && i.addEventListener("click", function (e) {
            if (e.target.parentElement.id == 'ma-close-popup' )
            e.preventDefault(), messagePanel.remove();
        })    
        
    },
    remove : function(){
        var element = document.getElementById('ma-import-container');
        if (element){
            element.outerHTML = "";
            delete element;     
        }    
    },
    render : function (t){
        
        messagePanel.init(t);
           
        var get_btn_html = function(buttons){
             var html = '';
             var actions = messagePanel.state.actions;
             
             if (typeof actions == 'undefined') return html; 
            
             for (var t = 0; t < actions.length;  t += 1){
                 var r = actions[t];
                 html += '<a ';
                 var tl = '';
                 for (var key in r) {
                    if (r.hasOwnProperty(key)) {
                        
                        if (key === 'title') tl = r[key]
                        else if (key === 'action') attach_button_action(r)
                        else if (key !== 'arg' && key !== 'action') html += ' ' + key + '="' + r[key] + '"';
    
                    }
                 }
        
                 html += '">' + tl + '</a>';   
             } 
    
             return html == '' ? '' : '<p>'+html+'</p>';    
        }
        
        var get_status_html = function(){
            var icon = messagePanel.state.iconUrl;
            return (typeof icon == 'undefined') ? '' : '<div class="img"><img src="' + chrome.extension.getURL(icon) +'"></div>'; 
        }
        
        var attach_button_action = function(action){
            var i = document.querySelector("body");
                i && i.addEventListener("click", function (e) {
                    if (e.target.id == action.id )
                    e.preventDefault(), action.action(action.arg);
                })    
        }
        

        
       var t = '<div id="ma-import-container" class="ma-panel ma-panel-import"><div class="ma-panel-header" style="text-align: -webkit-center;">' +
         '<a href="#" id="ma-close-popup" class="close"><img src="' + messagePanel.iconClose + '"></a> <img src="' + messagePanel.svgLogo + '" alt="ma logo" class="ma-logo"></div>' +
         '<div id="ma-panel-import-content" class="ma-panel-import-content"><div>' + get_status_html() +
         '<h2><div>' + messagePanel.state.text + '</div></h2> <div></div>' + get_btn_html() + '</div></div></div>';
         
       MAHtml.appendHtml(document, document.body, t);
    }
}

var MA_Auth = {
    setLastAuthError : function(e){
        chrome.storage.sync.set({ ma_auth_error: e}, function(){});    
    },
    getLastAuthError : function(f){
           chrome.storage.sync.get({
            ma_auth_error: false,
          }, function(data) {
            f(data.ma_auth_error);     
          })   
    },
    //background:
    ensureAuthCookie : function(f){
         chrome.storage.sync.get({
            ma_root_cookie: false,
          }, function(data) {
              if (data.ma_root_cookie === false){   
                  MA_Auth.generateAuthCookie(f);    
              } else {
                  MA_Auth.validateAuthCookie(data.ma_root_cookie, function(e) { 
                      if (e.valid) f(e.cookie);
                      else {
                          MA_Auth.generateAuthCookie(f);    
                      }
                  } );
                  
                 /* chrome.runtime.sendMessage({
                        action: config.actions.CONTENT_VALIDATE_AUTH_COOKIE,
                        cookie: data.ma_root_cookie
                  }, function(e) { 
                      if (e.valid) f(e.cookie);
                      else {
                          MA_Auth.generateAuthCookie(f);    
                      }
                  }); */
              }
              
                
          })
    },
    validateAuthCookie : function (cookie, f){
          var ext_options;
              
          var getValidateAuthCookiePromise = function(e){
            return (0, get_xhr_promise)({
                url: ext_options.root_url + config.api.validateAuthCookie,
                method: "POST",
                params: e,
                isForm: !0,
                isAjax: !0
            })
          }
     
          var validateAuthCookie = function(c, t) {
            var r = this,
                n = {cookie: c};
            getValidateAuthCookiePromise(n).then(function(d){
                var p = {cookie: n.cookie, status: d.statusText, valid: d.data.valid};
                t(p)
            }).catch(function(e) {
                  if ( e.resultType === "timeout" ){
                            console.log("Generate Auth Cookie Timeout");
                            setTimeout(function(){
                                validateAuthCookie(n.cookie, t);    
                            }, 600);    
                  } else {
                        console.log("Generate Auth Cookie Failed"), console.log(e), t(e)
                 }
            })
          }
          
     
          config.get_ext_options(function(v){
            ext_options = v;
            validateAuthCookie(cookie, f);
          });     
    }, 
    generateAuthCookie : function(f){
       /*   messagePanel.render({
            iconClose : chrome.extension.getURL(config.assets.iconClose),
            svgLogo : chrome.extension.getURL(config.assets.svgLogo),
            state: MA_Auth.getGenerateAuthCookieStateData()
          }); */
                 
        /*  chrome.runtime.sendMessage({
                action: config.actions.CONTENT_GENERATE_AUTH_COOKIE
          }, function(e) { */
          
              var ext_options;
              
              var getAuthCookiePromise = function(e){
          
                return (0, get_xhr_promise)({
                    url: ext_options.root_url + config.api.generateAuthCookie,
                    method: "POST",
                    params: e,
                    isForm: !0,
                    isAjax: !0
                })
              }
         
              var getAuthCookie = function(t) {
                    var r = this,
                        n = {username: ext_options.username, 
                             password: ext_options.password};
                             
                    
                            
                  if (ext_options.root_url == false || n.username == false || n.password == false)
                  {
                         MA_Auth.setLastAuthError('Can`t find Active store');
                         t(false); 
                  }
                  
                  
                    getAuthCookiePromise(n).then(function(d){
                        var e = d.data;
      
                        chrome.storage.sync.set({ ma_root_cookie: e.cookie}, function(){});
                 
                        if (e.status === 'ok' && e.cookie) t(e.cookie);  
                        else {
                            if ( typeof e.error !== 'undefined' && e.error)
                                MA_Auth.setLastAuthError(e.error);
                            t(false); 
                        } 
                    
                    }).catch(function(e) {
                        console.log("Generate Auth Cookie"), console.log(e), t(false)
                    })
              }
              
         
              config.get_ext_options(function(v){
                ext_options = v;
                getAuthCookie(f);
              });
                
                // chrome.storage.sync.set({ ma_root_cookie: e.cookie}, function(){})
                 /*
                 messagePanel.render({
                    iconClose : chrome.extension.getURL(config.assets.iconClose),
                    svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                    state: MA_Auth.getGeneratedAuthCookieStateData(e)
                 });  */
                             
                /*if (e.status === 'ok' && e.cookie) f(e.cookie);  
                else f(false);*/  
                 
         /* })*/ 
    },
    
    //all:
    resetAuthCookie : function (f){
        chrome.storage.sync.set({ ma_root_cookie: false}, f)    
    }, 
    
    //content:
    testConnection : function (f){
        messagePanel.render({
            iconClose : chrome.extension.getURL(config.assets.iconClose),
            svgLogo : chrome.extension.getURL(config.assets.svgLogo),
            state: MA_Auth.getTestConnectionStateData()
        }); 
        
        chrome.runtime.sendMessage({ action: config.actions.CONTENT_TEST_CONNECTION
                  }, function(e) { 
    
                      messagePanel.render({
                        iconClose : chrome.extension.getURL(config.assets.iconClose),
                        svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                        state: MA_Auth.getTestedConnectionStateData(e)
                      });
                      
                      f(e);  
         });    
    },
    
    getTestConnectionStateData : function(){
           var t = {
                text: "Attempting to authenticate...",
                isBusy: true,  
            };
            return t
    },
    
    getTestedConnectionStateData : function(e){
        
         var t = {};
         if (e.status === 'ok'){
            t = {
                text: 'Connection is successful!', 
                isBusy: false,  
                iconUrl: config.assets.iconImportSuccess,
                actions: []
            };    
         } else {
             t = {
                text: 'Sorry your connection is failed, " ' + e.error +'"', 
                isBusy: false,  
                iconUrl: config.assets.iconImportError,
                actions: [{
                    id: "ma-to-settings",
                    href: "/options.html",
                    target: "_blank",
                    className: '',
                    title: "Configure settings",
                    arg: '',
                    action: MA_Auth.openSettingTab
                }]
            };    
         }
     
         return t;    
    },
    
    openSettingTab : function(){
         chrome.runtime.sendMessage({action: config.actions.CONTENT_OPEN_SETTING_TAB }, function(e) {});      
    }
}

var MAProduct = {  
    pushProduct: function(e, i, th, pmn, pmx, ttl, cur, f) {
                
       return new Promise(function(resolve, reject){        

             messagePanel.render({
                iconClose : chrome.extension.getURL(config.assets.iconClose),
                svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                state: MAProduct.getPushStateData({id : i}),
             });
                    
             chrome.runtime.sendMessage({
                action: config.actions.CONTENT_PUSH_PRODUCT_TO_APP,                
                url: e,
                id: i,
                thumb: th,
                price_min: pmn,
                price_max: pmx,
                title: ttl,
                currency: cur
             }, function(e) {
                if (e.status == 'OK') e.success = true; 
                else e.success = false; 
    
                config.get_ext_options(function(v){
                   
                    ext_options = v;
                    
                    messagePanel.render({
                        iconClose : chrome.extension.getURL(config.assets.iconClose),
                        svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                        state: MAProduct.getPushedStateData({id : e.id, url : e.url, th : e.th, pmn : e.pmn, pmx : e.pmx, ttl : e.ttl, cur : e.cur, success : e.success, api_root_url : ext_options.root_url,
                        msg : ((typeof e.status_text !== 'undefined') ? e.status_text : '')})
                    });
                });
                
                if(typeof f !== "undefined") f();
                
                
                 if (e.status == 'OK') resolve({data: e});
                 else reject(new Error( (typeof e.status_text !== 'undefined') ? e.status_text : '' ));
                   
             })
    
         
       });
       
    },
    pushProductSilent : function(e, i, th, pmn, pmx, ttl, cur){
          return new Promise(function(resolve, reject){
           //  setTimeout( function(){ 
                 chrome.runtime.sendMessage({
                    action: config.actions.CONTENT_PUSH_PRODUCT_TO_APP,
                  
                    url: e,
                    id: i,
                    thumb: th,
                    price_min: pmn,
                    price_max: pmx,
                    title: ttl,
                    currency: cur
                 }, function(e) {
                    if (e.status == 'OK') e.success = true;
                    else if (e.status == 'warning' && e.warning == "Product already exist"){
                        e.success = true;
                    }
                    else e.success = false; 
              
                     if (e.status == 'OK') resolve({data: e});
                     else reject(new Error( (typeof e.status_text !== 'undefined') ? e.status_text : '' ));
                       
                 });  
           // }, interval);       
       });    
    },   
    pushProductArr : function(p){
        
         var firstPush = '', failed_p = [];
         
         if (p.length > 0 ) firstPush = function(el){
             
             
              messagePanel.render({
                iconClose : chrome.extension.getURL(config.assets.iconClose),
                svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                state: MAProduct.getMassPushStateData({success : true, number : p.length}),
              });
             
                return  MAProduct.pushProductSilent(el.url, el.id, el.thumb, el.price_min, el.price_max, el.title, el.currency);  
         }(p[0]).then(function(){
                if (p.length > 1) {
            
                    var do_push  = function(p, t){
                        firstPush = firstPush.then(function(val){
                            
                            el = p[t]; 

                            if (t+1 < p.length) {
                                
                                messagePanel.render({
                                    iconClose : chrome.extension.getURL(config.assets.iconClose),
                                    svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                                    state: MAProduct.getMassPushStateData({success : true, number : p.length - t}),
                                 });
                                 
                                do_push(p, t+1);
                            } else if ( t+1 === p.length) {

                                var params = {success : !0};
                                if (failed_p.length > 0){
                                    params.success = false;
                                    params.error = failed_p.length + ' product(s) - not imported. Try to import them again?';
                                    params.arr = failed_p;
                                }

                                messagePanel.render({
                                    iconClose : chrome.extension.getURL(config.assets.iconClose),
                                    svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                                    state: MAProduct.getMassPushedStateData(params),
                                 });
                            }
                             
                            return MAProduct.pushProductSilent(el.url, el.id, el.thumb, el.price_min, el.price_max, el.title, el.currency);   
                            
                           
                         
                          //  }   
                        }).catch(function(err){

                            failed_p.push(el);

                            if (err.message === "Can`t find Active store"){
                                messagePanel.render({
                                    iconClose : chrome.extension.getURL(config.assets.iconClose),
                                    svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                                    state: MA_Auth.getTestedConnectionStateData({status : 'no', error: err.message}),
                                })
                            }
                            else {
                                console.log(err.message);
                            }
                        });    
                    }
                    
                    do_push(p, 1);
                   
                } else {
                    //for 1-length array

                    messagePanel.render({
                        iconClose : chrome.extension.getURL(config.assets.iconClose),
                        svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                        state: MAProduct.getMassPushedStateData({success : !0}),
                    });

                }
         }).catch(function(err){
             failed_p.push(p[0]);
            if (err.message === "Can`t find Active store"){

                messagePanel.render({
                    iconClose : chrome.extension.getURL(config.assets.iconClose),
                    svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                    state: MA_Auth.getTestedConnectionStateData({status : 'no', error: err.message}),
                });
            } else {
                messagePanel.render({
                    iconClose : chrome.extension.getURL(config.assets.iconClose),
                    svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                    state: MAProduct.getMassPushedStateData({success : false, error: err.message, arr : p, ind : 0}),
                });
            }
        });
         
         
    
    },
    sendProductHtml : function(e,i){
        
        messagePanel.render({
            iconClose : chrome.extension.getURL(config.assets.iconClose),
            svgLogo : chrome.extension.getURL(config.assets.svgLogo),
            state: MAProduct.getPushHtmlStateData({id : i}),
        });
         
        chrome.runtime.sendMessage({
            action: config.actions.GET_AND_PUSH_PRODUCT_HTML_TO_APP,
            url: e,
            id: i
        }, function(e) {
            if (e.status == 'OK') e.success = true; 
            else e.success = false; 
            
            config.get_ext_options(function(v){
               
                ext_options = v;
                
                messagePanel.render({
                    iconClose : chrome.extension.getURL(config.assets.iconClose),
                    svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                    state: MAProduct.getPushedHtmlStateData({id : e.id, success : e.success, api_root_url : ext_options.root_url,
                    msg : ((typeof e.status_text !== 'undefined') ? e.status_text : '')})
                });
            });
        })
        
    },
    syncProductList : function(){

         messagePanel.render({
            iconClose : chrome.extension.getURL(config.assets.iconClose),
            svgLogo : chrome.extension.getURL(config.assets.svgLogo),
            state: MAProduct.getSyncStateData()
         });
       
         
        chrome.runtime.sendMessage({
            action: config.actions.SYNC_PRODUCT_LIST
        }, function(e) {
            if (e.status == 'OK') e.success = true; 
            else e.success = false; 
            
             messagePanel.render({
                iconClose : chrome.extension.getURL(config.assets.iconClose),
                svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                state: MAProduct.getSyncedStateData({success : e.success, msg : ((typeof e.status_text !== 'undefined') ? e.status_text : '')}),
             });
             
            })    
    },
    removeProduct : function(e) {

        messagePanel.render({
            iconClose : chrome.extension.getURL(config.assets.iconClose),
            svgLogo : chrome.extension.getURL(config.assets.svgLogo),
            state: MAProduct.getRemoveStateData({id : e.id})
        });
            
        chrome.runtime.sendMessage({
            action: config.actions.CONTENT_DELETE_PRODUCT_FROM_APP,
            id: e.id
        }, function(e) {
    
            if (e.status == 'OK') e.success = true; 
            else
                e.success = false;
          
            messagePanel.render({
                iconClose : chrome.extension.getURL(config.assets.iconClose),
                svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                state: MAProduct.getRemovedStateData({id : e.id, success : e.success, 
                msg : ((typeof e.status_text !== 'undefined') ? e.status_text : '') })
            });
        })
    }, 
    
    getSyncStateData : function (){
       var e = {
            text: "Sync product data...",
            isBusy: true,  
       };
       return e
    },
    getSyncedStateData : function (e){
         var t = {};
         
        return e.success ? (t = {
            text: "Product data was synced Successfully." + "<br/><br/>" + e.msg, 
            iconUrl: config.assets.iconImportSuccess,
        }) : (t = {
            text: "Synchronization Failed." + "<br/><br/>" + e.msg, 
            iconUrl: config.assets.iconImportError,
        }), t
    },
    getPushStateData : function(e) {
            var e = {
                text: "Product (id: " + e.id + ") being Imported...",
                isBusy: true,  
            };
            return e
    }, 
    getMassPushStateData : function(e) {
            var e = {
                text: "Mass import product: " + e.number + " remaining, please wait...",
                isBusy: true,  
            };
            return e
    }, 
    getMassPushedStateData : function(e) {
            var t = {
                text: e.success ? "Mass import product: completed!" : "The mass import product: failed!\n" + e.error,
                isBusy: false,
                iconUrl: e.success ? config.assets.iconImportSuccess : config.assets.iconImportError,
                actions: []
            };

        return e.success ? void 0 : (t.actions = [{
            id: "ma-restart-button",
            href: "#",
            target: "_blank",
            className: '',
            title: "Yes, import",
            arg: e,
            action: function(i){
                MAProduct.pushProductArr(i.arr);
            }
        },{
            id: "ma-close-button",
            href: "#",
            target: "_blank",
            className: '',
            title: "No, close",
            arg: e,
            action : function(e){ messagePanel.remove()}
        }]), t
    },
    getPushedStateData : function(e) {
            var t = {
                text: e.success ? "Product (id: " + e.id + ") Imported Successfully." + "<br/><br/>" + e.msg : "Product (id: " + e.id + ") Import Failed." + "<br/><br/>" + e.msg, 
                isBusy: false,  
                iconUrl: e.success ? config.assets.iconImportSuccess : config.assets.iconImportError,
                actions: []
            };
            return e.success ? (t.actions = [{
                href:  e.api_root_url + config.api.product_list_url_part,
                target: "_blank",
                title: "Open Import List"
            }, {
                id: "ma-remove-product",
                href: "#",
                target: '',
                className: "ma-text-danger",
                title: "Remove",
                arg: e.id,
                action: function(i) { MAProduct.removeProduct({id: i}) }
            }]) : (t.actions = [{
                id: "ma-retry-button",
                href: "#",
                target: "_blank",
                className: '',
                title: "Try again",
                arg: e,
                action: function(i){ MAProduct.pushProduct(i.url, i.id, i.th, i.pmn, i.pmx, i.ttl, i.cur)}
            },{
                    id: "ma-to-settings",
                    href: "#settings",
                    target: "_blank",
                    className: '',
                    title: "Configure settings",
                    arg: '',
                    action: MA_Auth.openSettingTab
                }]), t
    }, 
    getPushHtmlStateData : function (e){
           var e = {
                text: "Product html (id: " + e.id + ") being Imported...",
                isBusy: true,  
            };
            return e    
    },
    getPushedHtmlStateData : function(e) {
            var t = {
                text: e.success ? "Product html (id: " + e.id + ") Imported Successfully." + "<br/><br/>" + e.msg : "Product html (id: " + e.id + ") Import Failed." + "<br/><br/>" + e.msg, 
                isBusy: false,  
                iconUrl: e.success ? config.assets.iconImportSuccess : config.assets.iconImportError,
                actions: []
            };
            return e.success ? (t.actions = [{
                id: "ma-close-button",
                href: "#",
                target: "_blank",
                className: '',
                title: "OK",
                arg: e,
                action : function(e){ messagePanel.remove()}
            }]) : (t.actions = [{
                id: "ma-retry-button",
                href: "#",
                target: "_blank",
                className: '',
                title: "Try again",
                arg: e,
                action: function(i){ MAProduct.sendProductHtml(i.url, i.id)}
            }]), t
    }, 
    getRemoveStateData : function(e) {
            var e = {
                text: "Deleting product (id: " + e.id + ")...",
                isBusy: true,  
            };
            return e
    },
    getRemovedStateData : function(e) {
         var t = {};
         
            return e.success ? (t = {
                text: "Product (id: " + e.id + ") deleted Successfully." + "<br/><br/>" + e.msg, 
                iconUrl: config.assets.iconImportSuccess,
            }) : (t = {
                text: "Product (id: " + e.id + ") deleted Failed." + "<br/><br/>" + e.msg, 
                iconUrl: config.assets.iconImportError,
            }), t
         
    },
    getAttrValueIndexes(html="", attrArray = []){
        var found = html.match(/window\.runParams = {([.\s\S]*?)};/i);
        var fullObjectStr = found && found[1]?found[1].trim():"";
        found = fullObjectStr.match(/data: {([.\s\S]*)},[.\s\S]*csrfToken/i); 
        var object = found && found[1]?JSON.parse("{"+found[1]+"}"):{};
        if(object.skuModule && object.skuModule.productSKUPropertyList){
        return attrArray.reduce((acc,aId)=>{
        const values = object.skuModule.productSKUPropertyList.reduce((acc,val,attrIndex)=>{
        let valIndex = val.skuPropertyValues.findIndex(v=>v.propertyValueId.toString()===aId.toString())
        return valIndex!==-1?[...acc,{attrIndex,valIndex}]:acc
        },[])
        return [...acc,...values];
        },[])
        }
        return []
    }	
}

var MAOrder = {
    updateOrder : function(e, f) {

        messagePanel.render({
            iconClose : chrome.extension.getURL(config.assets.iconClose),
            svgLogo : chrome.extension.getURL(config.assets.svgLogo),
            state: MAOrder.getUpdateStateData({id : e.id})
        });
        
         chrome.runtime.sendMessage({ 
             action: config.actions.CONTENT_ORDER_FULFILLMENT_RESPONSE, id: e.id }, function(e) {
              
                if (e.status == 'OK') e.success = true; 
                else
                    e.success = false;
              
                    messagePanel.render({
                        iconClose : chrome.extension.getURL(config.assets.iconClose),
                        svgLogo : chrome.extension.getURL(config.assets.svgLogo),
                        state: MAOrder.getUpdatedStateData({id : e.id, external_id : e.external_id, success : e.success, 
                        msg : ((typeof e.status_text !== 'undefined') ? e.status_text : '') })
                    });
					
					if (typeof f !== "undefined") f(e);
            })
    },
	
    sendStatus : function(e,f){
        chrome.runtime.sendMessage({
            action: config.actions.CONTENT_ORDER_FULFILLMENT_STATUS_RESPONSE, stage: e.stage }, function(e) {
            if (typeof f !== "undefined") f(e);
        })
    },	
    getUpdateStateData : function(e) {
            var e = {
                text: "Sync Order (id: " + e.id + ") with Woocommerce...",
                isBusy: true,  
            };
            return e
    },
    getUpdatedStateData : function(e) {
         var t = {};
         
            return e.success ? (t = {
                text: "Order (id: " + e.external_id + ") Synced Successfully." + "<br/><br/>" + e.msg, 
                iconUrl: config.assets.iconImportSuccess,
            }) : (t = {
                text: "Order (id: " + e.external_id + ") Syncing Failed." + "<br/><br/>" + e.msg, 
                iconUrl: config.assets.iconImportError,
            }), t
         
    },
    clear : function(f){
        chrome.storage.sync.set({
            orderId: !1,
            orderItems: !1,
            orderNumber: !1,
            shopName: !1,
            currentProduct: 0,
            orderData: !1,
            defaultShipping: "",
            note: !1,
            cartLoaded: !1,
            formFilled: 0,
            countrySet: 0,
            createdAt: !1,
        },function() {
          if (typeof f !== "undefined") f();
        });
    }	
}


var MAFunc = {

    serialize : function(obj, prefix) {
        var str = [],
            p;
        for (p in obj) {
            if (obj.hasOwnProperty(p)) {
                var k = prefix ? prefix + "[" + p + "]" : p,
                    v = obj[p];
                str.push((v !== null && typeof v === "object") ?
                    serialize(v, k) :
                    encodeURIComponent(k) + "=" + encodeURIComponent(v));
            }
        }
        return str.join("&");
    },

    goToPluginTab : function(f){

            chrome.runtime.sendMessage({
                action: config.actions.CONTENT_SWITCH_TO_PLUGIN_TAB_REQUEST}, function(e) {
                if (typeof f !== "undefined") f(e);
            })
    },


    parseAvailableProductShopcartIds : function() {
        var e = !0,
            t = !1,
            r = void 0;
        try {
            for (var n, o = document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next())
                .done); e = !0) {
                var i = n.value,
                    a = i.innerText.match(/availableProductShopcartIds":\s"([\d,]+)",/);
                if (null !== a) return a[1]
            }
        } catch (e) {
            t = !0, r = e
        } finally {
            try {
                !e && o.return && o.return()
            } finally {
                if (t) throw r
            }
        }
        return null
    },

    testRequest : function(){
        chrome.runtime.sendMessage({
            action: config.actions.CONTENT_TEST_REQUEST
        }, function (e) {

        })
    },

    setAliAddress : function(d){

        return new Promise(function(n, l) {

            setTimeout(function(){

                var t = MAFunc.parseCsrfToken(),
                i = MAFunc.parseAvailableProductShopcartIds();

                if (t !== null && i !== null) {
                    chrome.runtime.sendMessage({
                        action: config.actions.CONTENT_SET_ADDRESS, token: t, ids : i, data: d
                    }, function (e) {
                        return n(e);

                    });
                } else {
                    if (t == null) {
                        return l("can't get the aliexpress api token");
                    }
                    if (i == null){
                        return l("can't get cart product ids");
                    }
                }
            },1000);
        });
    },

    checkPageNotFound : function(u){
        return new Promise(function(n) {
            chrome.runtime.sendMessage({
                action: config.actions.CONTENT_TEST_PAGE_NOT_FOUND, url: u
            }, function (e) {
                return n(e);
            });
        });
    },

    parseCsrfToken : function() {
        var e = !0,
            t = !1,
            r = void 0;
        try {
            for (var n, o = document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next())
                .done); e = !0) {
                var i = n.value,
                    a = i.innerText.match(/\._csrf_token_\s=\s'(\w+)';/);
                if (null !== a) return a[1]
            }
        } catch (e) {
            t = !0, r = e
        } finally {
            try {
                !e && o.return && o.return()
            } finally {
                if (t) throw r
            }
        }
        return null
    }

}

var MAHtml = {
    prependHtml : function(e, t, r){
            if (t && r) {
                var o = e.createElement("template");
                //o.innerHTML = r, n ? t.append(o.content.firstChild) : t.prepend(o.content.firstChild)
                 o.innerHTML = r, t.prepend(o.content.firstChild)
            }
     },
    appendHtml : function(e, t, r){
        if (t && r) {
            var o = e.createElement("template");
            o.innerHTML = r;
            t.append(o.content.firstChild)
        }
    },
}

var MAMessages = {
    
    productPushButton : function() {
        var btnFloating = chrome.extension.getURL(config.assets.btnFloating);
        return '<a href="#" id="ma-push-button" class="ma-btn-push-product" title="Import product to Alibuilder"><img src="' + btnFloating + '" alt=""></a>'
    },
    
    categoryPushButton : function(){
      var btnFloating = chrome.extension.getURL(config.assets.btnFloating);
      return '<a href="#" class="ma-btn-push-category-product"><img src="' + btnFloating + '" alt=""></a>'
    },
    statusBar : function() { return  '<div id="ma-status-bar-container"></div>' } 
}

var MAStatusBar = {
     add : function(e) {
        var logoSM = chrome.extension.getURL(config.assets.logoSM);
        jQuery("#ma-status-bar-container").append('<div class="status-bar" style="background: url(' + logoSM + ') no-repeat 13px center #fff;">' + e + "</div>")
     },
     remove : function() {
        jQuery("#ma-status-bar-container").html("")
     }    
}


var MAPromises = {
    clickBtn : function(e) {
            return new Promise(function(t, n) {
                var r = setInterval(function() {
                    
                    var n = e;
                    if (typeof e !== "object")
                        n = document.querySelector(e);
                    
                    n && (clearInterval(r), n.click(), t(n));
                   // console.log('try click on: '+e+'...')
                }, 400);
                setTimeout(function() {
                   // console.log('cant click on : '+e+'...');
                    clearInterval(r), n(!1);
                }, 5000)
            })
        },
    
    waitEl : function(e,c) {
            return new Promise(function(t, n) {
                var r = setInterval(function() {
                    
                    var n = e;
                    if (typeof e !== "object")
                        n = document.querySelector(e);
                    
                    if ( typeof c !== 'undefined' ){
                        if (c == ':visible'){
                             n && n.is(":visible") && (clearInterval(r), t(n));      
                        } else {
                             n && n.classList.contains(c) && (clearInterval(r), t(n));      
                        }
                         
                    } else {
                       n && (clearInterval(r), t(n));
                    }
                    
                    
                   // console.log('wait for: '+e+'...')
                }, 400);
                setTimeout(function() {
                   // console.log('there is no : '+e+'...');
                    clearInterval(r), n(!1);
                }, 20000)
            })
        }
        
}


